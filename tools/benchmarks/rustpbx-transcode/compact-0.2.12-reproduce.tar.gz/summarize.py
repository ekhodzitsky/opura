"""Aggregate all worker observations and verify the scheduled comparisons."""
import json, math, statistics
from pathlib import Path
r=Path(__file__).resolve().parent
plan=json.loads((r/'protocol.json').read_text())
rows=[json.loads(x) for x in (r/'raw.jsonl').read_text().splitlines()]
scheduled=[(x['test'],x['legs'],x['pair'],arm) for x in plan['schedule'] for arm in x['arms']]
assert [(x['test'],x['legs'],x['pair'],x['arm']) for x in rows]==scheduled
def p99(v):
    return sorted(v)[math.ceil(.99*len(v))-1]
result={}
for test,load in [('primary',250),('primary',500),('layout',500),('long',500)]:
    subset=[x for x in rows if (x['test'],x['legs'])==(test,load)]
    base='fixed' if test=='layout' else 'stock'; arms={}
    cpus={};rss={};miss={}
    for arm in [base,'opura']:
        a=[x for x in subset if x['arm']==arm]
        cpu=[x['cpu_ticks']/plan['ticks_per_second']/(x['batches']*.020) for x in a]
        m=[x['rss_kib']/1024 for x in a]; peak=[x['peak_kib']/1024 for x in a]
        all_lats=[l for x in a for l in x['latency_ns']]
        late=[sum(l>20000000 for l in x['latency_ns']) for x in a]
        cpus[arm]=cpu;rss[arm]=m;miss[arm]=sum(late)
        arms[arm]=dict(runs=len(a),cpu_median=statistics.median(cpu),cpu_range=[min(cpu),max(cpu)],
                       rss_median_mib=statistics.median(m),peak_median_mib=statistics.median(peak),
                       pooled_p99_ms=p99(all_lats)/1e6,worst_batch_ms=max(all_lats)/1e6,late=sum(late),
                       late_by_process=late,all_batches=len(all_lats),fnv=a[0]['fnv'],silent_frames=a[0]['silent_frames'])
        assert len({(x['fnv'],x['silent_frames']) for x in a})==1
    assert arms[base]['fnv']==arms['opura']['fnv'] and arms[base]['silent_frames']==arms['opura']['silent_frames']
    ratio=[o/s for o,s in zip(cpus['opura'],cpus[base])]
    gm=math.exp(statistics.mean(math.log(x) for x in ratio))
    frac=statistics.median(rss['opura'])/statistics.median(rss[base])
    result[f'{test}_{load}']=dict(arms=arms,cpu_ratio=gm,cpu_ratio_range=[min(ratio),max(ratio)],
                                cpu_ratios=ratio,rss_ratio=frac,memory_reduction_mib=statistics.median(rss[base])-statistics.median(rss['opura']),
                                release_gate=dict(rss=frac<=.8,cpu=gm<=1.0,deadline=miss['opura']<=miss[base]) if base=='stock' else None)
(r/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:(v['cpu_ratio'],v['rss_ratio'],v['release_gate']) for k,v in result.items()}))
