"""Run the frozen RustPBX media path schedule serially on one logical CPU."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

def sha(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("binary", type=Path)
    ap.add_argument("golos", type=Path)
    ap.add_argument("ami", type=Path)
    ap.add_argument("protocol", type=Path)
    ap.add_argument("outdir", type=Path)
    cfg=ap.parse_args()
    arms_binary=cfg.binary.resolve(strict=True)
    data={"golos":cfg.golos.resolve(strict=True),"ami":cfg.ami.resolve(strict=True)}
    plan=json.loads(cfg.protocol.read_text())
    cpu,=plan["cpu_affinity"]
    assert os.sysconf("SC_CLK_TCK")==plan["ticks_per_second"]
    for name, expected in plan["golos_packet_sha256"].items():
        assert sha(data["golos"]/name)==expected
    assert sha(data["ami"]/"manifest.json")==plan["ami_manifest_sha256"]
    for clip in json.loads((data["ami"]/"manifest.json").read_text())["clips"]:
        assert sha(data["ami"]/clip["file"])==clip["sha256"]
    ids={"binary_sha256":sha(arms_binary),"protocol_sha256":sha(cfg.protocol),
         "governor":Path(f"/sys/devices/system/cpu/cpu{cpu}/cpufreq/scaling_governor").read_text().strip()}
    with (cfg.outdir/"timed-identities.json").open("x") as f: json.dump(ids,f,indent=2);f.write("\n")
    with (cfg.outdir/"raw.jsonl").open("x") as out:
        for pair in plan["schedule"]:
            signatures=[]
            for arm in pair["arms"]:
                n=pair["batches"]; legs=pair["legs"]
                cmd=["taskset","-c",str(cpu),str(arms_binary),arm,str(legs),str(data[pair["corpus"]])]
                start=time.time_ns()
                proc=subprocess.run(cmd,env=dict(os.environ,PBX_TIMED_BATCHES=str(n)),
                     stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=45,check=False)
                end=time.time_ns()
                if proc.returncode != 0: raise RuntimeError((pair,arm,proc.returncode,proc.stderr))
                row=json.loads(proc.stdout)
                assert row["legs"]==legs and row["ticks"]==n and row["frames"]==n*legs
                assert len(row["latency_ns"])==len(row["latency_us"])==n
                assert all(v>0 and v//1000==u for v,u in zip(row["latency_ns"],row["latency_us"]))
                assert 0 <= row["silent_frames"] < row["frames"] and row["cpu_ticks"]>0
                signatures.append((row["fnv"],row["silent_frames"]))
                row.update({k:v for k,v in pair.items() if k!="arms"},arm=arm,
                           realtime_start_ns=start,process_elapsed_ns=end-start)
                print(json.dumps(row,separators=(",",":")),file=out,flush=True)
            assert signatures[0]==signatures[1],(pair,signatures)
            print(pair["test"],legs,pair["pair"],flush=True)
if __name__=="__main__":
    main()
