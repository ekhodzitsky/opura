#!/bin/sh
set -eu
if [ "$#" -ne 3 ]; then
    echo "Usage: sh build.sh OPURA_CHECKOUT RUSTPBX_CHECKOUT NEW_WORK_DIRECTORY" >&2
    exit 2
fi
opura=$(realpath "$1")
pbx=$(realpath "$2")
assets=$(dirname "$(realpath "$0")")
mkdir "$3"
work=$(realpath "$3")
mkdir -p "$work/stage" "$work/rustpbx" "$work/runner/src"
base=6a38d656af967e8e3c70c9fea5f505add5f80e25
upstream=339f75b99341bcfc440545d70294f5de55652525
for name in main.rs opura_probe.rs Cargo.toml.in Cargo.lock.gz; do
    git -C "$opura" show "$base:tools/benchmarks/rustpbx-transcode/$name" > "$work/stage/$name"
done
gzip -dc "$work/stage/Cargo.lock.gz" > "$work/stage/Cargo.lock"
(cd "$work/stage" && patch -s -p1 < "$assets/worker.patch")
git -C "$pbx" archive -o "$work/upstream.tar" "$upstream"
tar xf "$work/upstream.tar" -C "$work/rustpbx"
rm "$work/upstream.tar"
(cd "$work/rustpbx" && patch -s -p1 < "$assets/egress.patch")
cp "$work/stage/opura_probe.rs" "$work/rustpbx/crates/rustpbx-media/src/"
cp "$work/stage/Cargo.toml.in" "$work/runner/Cargo.toml"
cp "$work/stage/main.rs" "$work/runner/src/"
cp "$work/stage/Cargo.lock" "$work/runner/"
cd "$work/runner"
cargo +1.100.0 build --release --locked
