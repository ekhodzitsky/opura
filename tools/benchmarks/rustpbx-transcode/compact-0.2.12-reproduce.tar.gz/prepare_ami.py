"""Prepare 15 disjoint AMI excerpts for a continuous PCMU transcode test."""
import argparse
from collections import Counter
import hashlib
import json
import shutil
import subprocess
import wave
from pathlib import Path

def sha(blob):
    return hashlib.sha256(blob).hexdigest()

def ogg_packets(blob):
    offset = 0
    pending = bytearray()
    while offset < len(blob):
        assert blob[offset:offset + 4] == b"OggS"
        count = blob[offset + 26]
        lengths = blob[offset + 27:offset + 27 + count]
        offset += 27 + count
        for length in lengths:
            pending.extend(blob[offset:offset + length])
            offset += length
            if length < 255:
                yield bytes(pending)
                pending.clear()
    assert not pending and offset == len(blob)

def duration_samples_48k(p):
    config, code = p[0] >> 3, p[0] & 3
    frame = ([480, 960, 1920, 2880][config % 4] if config < 12
             else [480, 960][config % 2] if config < 16 else [120, 240, 480, 960][config % 4])
    count = 1 if code == 0 else p[1] & 63 if code == 3 else 2
    return frame * count

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.mkdir(exist_ok=False)
    cmd = ["ffmpeg", "-nostdin", "-v", "error", "-f", "s16le", "-ar", "16000", "-ac", "1",
           "-i", "pipe:0", "-map_metadata", "-1", "-c:a", "libopus", "-application", "voip",
           "-frame_duration", "20", "-b:a", "24000", "-vbr", "off", "-compression_level", "10",
           "-fflags", "+bitexact", "-flags", "+bitexact", "-f", "ogg", "pipe:1"]
    receipt = {"sources": {}, "clips": [], "encoder_args": cmd,
               "ffmpeg": subprocess.check_output(["ffmpeg", "-version"], text=True).splitlines()[0],
               "ffmpeg_sha256": sha(Path(shutil.which("ffmpeg")).read_bytes())}
    for meeting_no, meeting in enumerate(["ES2002a", "IS1000a", "TS3003a"]):
        wpath = args.source / f"{meeting}.wav"
        receipt["sources"][meeting] = {
            "sha256": sha(wpath.read_bytes()),
            "url": f"https://groups.inf.ed.ac.uk/ami/AMICorpusMirror/amicorpus/{meeting}/audio/{meeting}.Mix-Headset.wav",
        }
        with wave.open(str(wpath), "rb") as w:
            assert (w.getnchannels(), w.getframerate(), w.getsampwidth()) == (1, 16000, 2)
            for part, start in enumerate([60, 84, 108, 132, 156]):
                w.setpos(start * 16000)
                pcm = w.readframes(21 * 16000)
                assert len(pcm) == 21 * 16000 * 2
                blob = subprocess.run(cmd, input=pcm, check=True, capture_output=True).stdout
                h, tags, *packets = list(ogg_packets(blob))
                assert h.startswith(b"OpusHead") and tags.startswith(b"OpusTags")
                assert len(packets) == 1051
                configs = dict(sorted(Counter(p[0] for p in packets).items()))
                assert all(len(p) == 60 and p[0] & 4 == 0 and duration_samples_48k(p) == 960 for p in packets), configs
                packed = b"".join(len(p).to_bytes(4, "big") + p for p in packets)
                fname = f"golos_{part * 3 + meeting_no:02}"
                (args.output / fname).write_bytes(packed)
                receipt["clips"].append({"file": fname, "meeting": meeting, "start_s": start,
                    "seconds": 21, "pcm_sha256": sha(pcm), "sha256": sha(packed),
                    "toc_histogram": configs, "20ms_mono_packets": len(packets)})
    receipt["clips"].sort(key=lambda x:x["file"])
    (args.output / "manifest.json").write_text(json.dumps(receipt, indent=2) + "\n")

if __name__ == "__main__":
    main()
