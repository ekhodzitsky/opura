import array,bisect,collections,subprocess,sys,json
from pathlib import Path
dump,bin=map(Path,sys.argv[1:3]);data=array.array('H');data.frombytes(dump.read_bytes()[:dump.stat().st_size//2*2])
nm=subprocess.check_output(['nm','-nC','--defined-only',str(bin)],text=True)
syms=[]
for l in nm.splitlines():
 s=l.split(maxsplit=2)
 if len(s)==3 and s[1] in ('t','T'):syms.append((int(s[0],16),s[2]))
addrs=[a for a,n in syms];totals=collections.Counter()
for k,c in enumerate(data):
 if c:
  idx=bisect.bisect_right(addrs,2*k)-1
  totals[syms[idx][1] if idx>=0 else 'outside']+=c
counts=totals.most_common();print(json.dumps({'samples':sum(totals.values()),'functions':counts[:120]},indent=2))
