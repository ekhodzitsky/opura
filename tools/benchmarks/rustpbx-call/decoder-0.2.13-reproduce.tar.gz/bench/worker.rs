use std::{env,fs,hint::black_box,io::Write};
use audio_codec::{Decoder,opus::OpusDecoder};
fn packets(path: &str) -> Vec<Vec<u8>> {
    let b=fs::read(path).unwrap();
    let mut s=&b[..];
    let mut result=Vec::new();
    while !s.is_empty(){
        let len=u32::from_be_bytes(s[..4].try_into().unwrap()) as usize;
        result.push(s[4..4+len].to_vec());s=&s[4+len..];
    }
    assert!(!result.is_empty());result
}
fn cpu() -> u64 { fs::read_to_string("/proc/thread-self/schedstat").unwrap().split_whitespace().next().unwrap().parse().unwrap() }
fn emit(out: &[i16], dump: &mut Option<std::io::BufWriter<fs::File>>){
    if let Some(w)=dump {
        for &x in out { w.write_all(&x.to_le_bytes()).unwrap(); }
    }
    black_box(out);
}
fn adapter(p: &[Vec<u8>],dump:&mut Option<std::io::BufWriter<fs::File>>){
    let mut d=OpusDecoder::new(48000,1);
    for packet in p {
        let pcm=d.decode(black_box(packet));
        assert!(!pcm.is_empty());
        emit(&pcm,dump);
    }
}
#[cfg(not(feature="reference"))]
fn core(p:&[Vec<u8>], dump:&mut Option<std::io::BufWriter<fs::File>>){
    use opura::{decoder::CompactOpusDecoder as D,silk::{resampler::OutputRate,decoder::PcmChannels as C}};
    let make=|c| D::new(OutputRate::Khz48,if c==2 {C::Stereo} else {C::Mono}).unwrap();
    let mut channels=1;
    let mut d=make(channels);
    let mut out=[0i16;1920];
    for packet in p {
        let c=if packet[0]&4!=0 {2} else {1};
        if c!=channels{ d=make(c);channels=c; }
        let n=d.decode_into(black_box(packet),&mut out).unwrap();
        emit(&out[..n],dump);
    }
}
#[cfg(feature="reference")]
fn core(p:&[Vec<u8>],dump:&mut Option<std::io::BufWriter<fs::File>>){
    let make=|c| opus_rs::OpusDecoder::new(48000,c).unwrap();
    let mut channels=1;
    let mut d=make(channels);
    let mut out=[0f32;1920];
    for packet in p {
        let c=if packet[0]&4!=0 {2} else {1};
        if c!=channels {d=make(c);channels=c;}
        let n=d.decode(black_box(packet),960,&mut out).unwrap()*c;
        if dump.is_some(){
            let pcm=out[..n].iter().map(|v|(v*32768.).clamp(-32768.,32767.) as i16).collect::<Vec<_>>();
            emit(&pcm,dump);
        }
        black_box(&out[..n]);
    }
}
fn main(){
    let a=env::args().collect::<Vec<_>>();let pkts=packets(&a[1]);
    let f=match a[2].as_str(){"adapter"=>adapter,"core"=>core,_=>panic!()};
    let repeats: usize=a[3].parse().unwrap();
    let mut dump=a.get(4).map(|p|std::io::BufWriter::new(fs::File::create(p).unwrap()));
    f(&pkts,&mut dump);drop(dump);
    let before=cpu(); for _ in 0..repeats{ f(&pkts,&mut None); } println!("{}",cpu()-before);
}
