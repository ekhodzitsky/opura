#define _GNU_SOURCE
#include <link.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
static uintptr_t image_base;
static size_t length;
static unsigned short *samples;
static int locate(struct dl_phdr_info *d, size_t sz, void *p) {
    if (!d->dlpi_name || d->dlpi_name[0] == 0) {
        image_base=d->dlpi_addr;
        for (int i=0;i<d->dlpi_phnum;i++){
            const ElfW(Phdr) *s=&d->dlpi_phdr[i];
            if(s->p_type==PT_LOAD&&(s->p_flags&PF_X))length=s->p_vaddr+s->p_memsz+16;
        }
        return 1;
    }return 0;
}
__attribute__((constructor)) static void begin(void) {
    dl_iterate_phdr(locate,NULL);
    samples=calloc((length+1)/2,sizeof(*samples));if(!samples||!length||profil(samples,length,image_base,65536))_exit(91);
}
__attribute__((destructor)) static void end(void) {
    profil(NULL,0,0,0);FILE*f=fopen(getenv("SAMPLER_OUT"),"wb");if(!f)_exit(92);
    fwrite(samples,1,length,f);fclose(f);
}
