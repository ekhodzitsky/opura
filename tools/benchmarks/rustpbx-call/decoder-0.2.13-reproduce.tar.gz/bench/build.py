"""Build one frozen SIP packet replay from a checksummed audio-codec crate and release source."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
import tomllib

script = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("arm", choices=["base", "stock", "candidate"])
parser.add_argument("audio_codec_crate", type=Path)
parser.add_argument("directory", type=Path, help="new build directory")
parser.add_argument("--candidate-source", type=Path, help="path to candidate Opura checkout")
args = parser.parse_args()
assert subprocess.check_output(["rustc", "-V"], text=True).startswith("rustc 1.98.1 (48a229cea")
checksum = hashlib.sha256(args.audio_codec_crate.read_bytes()).hexdigest()
assert checksum == "81c2b027ac91f3fb0c9c001e43538ea4523c7c3e2bc3feb4f380abac07604490"
build = args.directory.resolve()
build.mkdir()
with tarfile.open(args.audio_codec_crate) as archive:
    archive.extractall(build, filter="data")
codec = build / "audio-codec"
(build / "audio-codec-0.4.6").rename(codec)
if args.arm != "stock":
    subprocess.run(["patch", "-s", "-p1", "-i", script / "adapter.patch"], cwd=codec, check=True)
opura_dep = 'version="=0.2.12"'
if args.arm == "candidate":
    if args.candidate_source is None:
        parser.error("supply --candidate-source for the candidate arm")
    opura_dep = "path=" + json.dumps(str(args.candidate_source.resolve()))
    m = codec / "Cargo.toml"
    anchored = '[dependencies.opura]\nversion = "=0.2.12"'
    assert m.read_text().count(anchored) == 1
    m.write_text(m.read_text().replace(anchored, "[dependencies.opura]\n" + opura_dep))
worker = build / "worker"
(worker / "src").mkdir(parents=True)
lock = (script / "locks" / (args.arm + ".lock")).read_text()
if args.arm == "candidate":
    # The qualification used a pre-release tree. Allow its release-only version bump.
    pkg = tomllib.loads((args.candidate_source / "Cargo.toml").read_text())["package"]
    key = 'name = "opura"\nversion = "0.2.12"'
    assert lock.count(key) == 1
    lock = lock.replace(key, 'name = "opura"\nversion = ' + json.dumps(pkg["version"]))
(worker / "Cargo.lock").write_text(lock)
shutil.copyfile(script / "worker.rs", worker / "src/main.rs")
(worker / "Cargo.toml").write_text(f'''[package]
name="sip-replay"
version="0.0.0"
edition="2021"
[features]
reference=[]
[dependencies]
audio-codec={{path="../audio-codec"}}
opura={{{opura_dep}}}
opus-rs={{version="=0.1.32",default-features=false,features=["std","heap","libm"]}}
[profile.release]
opt-level=2
lto=false
strip=false
''')
cmd = ["cargo", "build", "--release", "--locked"]
if args.arm == "stock":
    cmd.extend(["--features", "reference"])
subprocess.run(cmd, cwd=worker, env={**os.environ, "CARGO_TARGET_DIR":str(build / "target")}, check=True)
(script / "bin").mkdir(exist_ok=True)
shutil.copy2(build / "target/release/sip-replay", script / "bin" / args.arm)
