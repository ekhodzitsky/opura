import json,statistics as S,random,math,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent
plan=json.loads((r/'protocol.json').read_text())
phase,path=sys.argv[1],Path(sys.argv[2]).resolve()
if not path.is_file():raise RuntimeError(path)
raw=r/(phase+'-raw.jsonl')
with raw.open('x') as out:
 for i,row in enumerate(plan[phase],1):
  for item in row:
   arm,mode=item.split('-') if phase=='diagnosis' else (item,'adapter' if phase=='adapter' else 'core')
   n=plan['iterations'][phase]
   value=int(subprocess.check_output(['taskset','-c','4',r/'bin'/arm,path,mode,str(n)]))
   out.write(json.dumps(dict(round=i,arm=arm,mode=mode,repeats=n,cpu_ns=value))+'\n');out.flush()
records=[json.loads(x) for x in raw.read_text().splitlines()]
ns={}
for x in records:ns.setdefault(x['arm']+'-'+x['mode'],[]).append(x['cpu_ns']/x['repeats'])
def paired(a,b):
 ratios=[x/y for x,y in zip(ns[a],ns[b])]
 blocks=[S.mean(math.log(r) for r in ratios[k:k+2]) for k in range(0,len(ratios),2)]
 rng=random.Random(124)
 boot=sorted(math.exp(S.mean(rng.choices(blocks,k=len(blocks)))) for i in range(50000))
 return {'ratio':S.geometric_mean(ratios),'ci':[boot[1249],boot[48749]],'ratios':ratios}
result={'medians_cpu_ns_per_pass':{k:S.median(v) for k,v in ns.items()}}
if phase=='diagnosis':
 for m in ('core','adapter'):
  result[m]=paired('base-'+m,'stock-'+m)
 for arm in ('base','stock'):result[arm+'_adapter_over_core']=paired(arm+'-adapter',arm+'-core')
else:
 m='adapter' if phase=='adapter' else 'core';result['candidate_over_baseline']=paired('candidate-'+m,'base-'+m)
(r/(phase+'-summary.json')).write_text(json.dumps(result,indent=2)+'\n')
print({k:(v['ratio'],v['ci']) for k,v in result.items() if 'ratio' in v})
