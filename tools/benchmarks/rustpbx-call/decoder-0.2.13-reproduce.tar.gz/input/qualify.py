"""Check each captured Opus packet and its final range with an external libopus."""
import ctypes as C
import ctypes.util
import hashlib
import json
import struct
import sys
from pathlib import Path

src=Path(sys.argv[1])
lib=C.CDLL(ctypes.util.find_library('opus'))
def function(name,args,result):
    f=getattr(lib,name); f.argtypes=args;f.restype=result;return f
ptr=C.c_void_p
i32=C.c_int32
vp=C.c_void_p
getver=function('opus_get_version_string',[],C.c_char_p)
samples=function('opus_packet_get_nb_samples',[ptr,i32,i32],i32)
nch=function('opus_packet_get_nb_channels',[ptr],C.c_int)
frames=function('opus_packet_get_nb_frames',[ptr,i32],C.c_int)
band=function('opus_packet_get_bandwidth',[ptr],C.c_int)
create=function('opus_decoder_create',[i32,C.c_int,C.POINTER(C.c_int)],vp)
destroy=function('opus_decoder_destroy',[vp],None)
decode=function('opus_decode',[vp,ptr,i32,C.POINTER(C.c_int16),i32,C.c_int],i32)
ctl=function('opus_decoder_ctl',[vp,C.c_int,C.POINTER(C.c_uint32)],C.c_int)
pkt_bytes=src.read_bytes(); at=0;n=0
pcm=(C.c_int16*5760)();err=C.c_int()
state=create(48000,1,C.byref(err));assert state and err.value==0
levels=set();franges=hashlib.sha256();stream=hashlib.sha256()
try:
    while at<len(pkt_bytes):
        nbytes=struct.unpack_from('>I',pkt_bytes,at)[0];at+=4
        packet=pkt_bytes[at:at+nbytes];at+=nbytes
        assert nbytes and len(packet)==nbytes
        assert frames(packet,nbytes)==1 and nch(packet)==1
        assert samples(packet,nbytes,48000)==960 and band(packet)==1105
        assert decode(state,packet,nbytes,pcm,5760,0)==960
        stream.update(C.string_at(C.addressof(pcm),960*2))
        final=C.c_uint32();assert ctl(state,4031,C.byref(final))==0
        franges.update(struct.pack('>I',final.value));levels.add(final.value);n+=1
finally:
    destroy(state)
assert n==1600 and at==len(pkt_bytes)
print(json.dumps(dict(packets=n,external_libopus=getver().decode(),length_prefixed_packets_sha256=hashlib.sha256(pkt_bytes).hexdigest(),frames_per_packet=1,bandwidth='fullband',channels=1,output_samples_per_packet=960,output_rate_hz=48000,distinct_final_ranges=len(levels),packet_final_ranges_u32_be_sha256=franges.hexdigest(),external_decoder_s16le_pcm_sha256=stream.hexdigest()),indent=2))
