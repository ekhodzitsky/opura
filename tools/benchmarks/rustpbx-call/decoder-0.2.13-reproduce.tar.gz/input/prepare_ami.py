"""Extract the 32-second ES2002a holdout used by the SIP packet replay."""
import argparse
import hashlib
from pathlib import Path
import wave

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('source', type=Path, help='AMI ES2002a.Mix-Headset.wav')
parser.add_argument('output', type=Path, help='Output path for the 32-second mono WAV')
args = parser.parse_args()
source_hash = '9c76866990fcc8b84006dc32d273ad99df439090b748ebe72103bb78c3216ee7'
expected_hash = '8572e076377a2d6832a76c459a6b9acf36bd66b02cf18dcb7ef723a92d4c0825'
with args.source.open('rb') as source:
    if hashlib.file_digest(source, 'sha256').hexdigest() != source_hash:
        parser.error('Expected the original ES2002a mixed-headset WAV')
with wave.open(str(args.source)) as wave_in:
    if (wave_in.getframerate(), wave_in.getnchannels(), wave_in.getsampwidth()) != (16000, 1, 2):
        parser.error('Expected 16 kHz, mono, signed 16-bit PCM')
    wave_in.setpos(345 * 16000)
    pcm = wave_in.readframes(32 * 16000)
if len(pcm) != 32 * 16000 * 2:
    parser.error('The source does not contain the requested interval')
with args.output.open('xb') as destination, wave.open(destination, 'wb') as wave_out:
    wave_out.setparams((1, 2, 16000, 0, 'NONE', 'not compressed'))
    wave_out.writeframes(pcm)
if hashlib.sha256(args.output.read_bytes()).hexdigest() != expected_hash:
    raise SystemExit('Excerpt checksum mismatch')
