"""Record the public speech fixture from the original sipbot binary at our own RTP endpoint."""
import argparse, hashlib, json, os, re, selectors, socket, struct, subprocess, time, wave
from collections import Counter
from pathlib import Path

ap=argparse.ArgumentParser()
ap.add_argument('sipbot',type=Path)
ap.add_argument('wav',type=Path)
ap.add_argument('out',type=Path)
ap.add_argument('--seconds',type=int,default=32)
ap.add_argument('--tail',type=int,default=0,help='Extra hangup margin after the collected audio duration')
ap.add_argument('--expected-wav',default='d9d19ffacfd369cd8996dd302dd9deadb0531fba537aef232cad3fa7f89f45e2')
cfg=ap.parse_args()
assert {x[1] for x in socket.if_nameindex()}=={'lo'}
wav=cfg.wav.resolve(); sipbot=cfg.sipbot.resolve(); out=cfg.out.resolve();out.mkdir()
assert hashlib.sha256(wav.read_bytes()).hexdigest()==cfg.expected_wav
with wave.open(str(wav)) as w,wave.open(str(out/'loop.wav'),'wb') as dest:
    dest.setparams(w.getparams()); dest.writeframes(w.readframes(w.getnframes())*(1+((cfg.seconds+1)*w.getframerate()//w.getnframes())))
sel=selectors.DefaultSelector()
sip=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);sip.bind(('127.0.0.1',15090));sel.register(sip,selectors.EVENT_READ)
rtp=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);rtp.bind(('127.0.0.1',28720));sel.register(rtp,selectors.EVENT_READ)
sdp='\r\n'.join(['v=0','o=- 1 1 IN IP4 127.0.0.1','s=-','c=IN IP4 127.0.0.1','t=0 0','m=audio 28720 RTP/AVP 111 101','a=sendrecv','a=ssrc:10000 cname:public-fixture','a=rtpmap:111 opus/48000/2','a=fmtp:111 minptime=10;useinbandfec=1;stereo=1;sprop-stereo=0','a=rtpmap:101 telephone-event/48000','a=fmtp:101 0-16',''])
seqs=[];tss=[];toc=Counter();payload_bytes=0;offset=0
argv=[str(sipbot),'--conf',str(out/'unused.toml'),'call','--target','sip:bob@127.0.0.1:15090','--username','alice','--addr','127.0.0.1:15091','--codecs','opus','--hangup',str(cfg.seconds+cfg.tail),'--total','1','--cps','1','--play',str(out/'loop.wav'),'--audio-quality','-v']
with (out/'caller.log').open('wb') as log,(out/'packets.bin').open('xb') as packed:
    proc=subprocess.Popen(argv,cwd=out,stdout=log,stderr=log)
    deadline=time.monotonic()+cfg.seconds+cfg.tail+12
    try:
        while time.monotonic()<deadline:
            for key,_ in sel.select(.1):
                data,peer=key.fileobj.recvfrom(65536);assert peer[0]=='127.0.0.1'
                if key.fileobj is sip:
                    msg=data.decode(); method=msg.split(' ',1)[0]
                    if method=='ACK':continue
                    assert method in ('INVITE','BYE','OPTIONS','CANCEL'),method
                    hdr={k.lower():v.strip() for k,v in (l.split(':',1) for l in msg.split('\r\n\r\n',1)[0].split('\r\n')[1:])}
                    body=sdp if method=='INVITE' else ''
                    lines=['SIP/2.0 200 OK','Via: '+hdr['via'],'From: '+hdr['from'],'To: '+hdr['to']+('' if 'tag=' in hdr['to'] else ';tag=packet-replay'),'Call-ID: '+hdr['call-id'],'CSeq: '+hdr['cseq'],'Contact: <sip:bob@127.0.0.1:15090>']
                    if body:lines+=['Content-Type: application/sdp']; assert 'a=rtpmap:111 opus/48000/2' in msg
                    lines+=['Content-Length: '+str(len(body)), '', body]
                    sip.sendto('\r\n'.join(lines).encode(),peer)
                else:
                    if len(seqs)>=cfg.seconds*50 or len(data)<12 or data[0]>>6!=2 or data[1]&127!=111:continue
                    off=12+4*(data[0]&15)
                    if data[0]&16:off+=4+4*int.from_bytes(data[off+2:off+4],'big')
                    end=len(data)-(data[-1] if data[0]&32 else 0)
                    pay=data[off:end];assert pay
                    seqs.append(int.from_bytes(data[2:4],'big'));tss.append(int.from_bytes(data[4:8],'big'))
                    toc[pay[0]]+=1;payload_bytes+=len(pay)
                    packed.write(struct.pack('>I',len(pay))+pay)
                    if len(seqs)==5:
                        packed.flush(); print('FIRST_TOC',sorted(toc.items()),flush=True)
            if proc.poll() is not None:break
        assert proc.wait(timeout=1)==0
    finally:
        if proc.poll() is None:proc.kill();proc.wait()
assert len(seqs)==cfg.seconds*50,(len(seqs),cfg.seconds)
assert all((b-a)&0xffff==1 for a,b in zip(seqs,seqs[1:]))
assert all((b-a)&0xffffffff==960 for a,b in zip(tss,tss[1:]))
report=dict(packets=len(seqs),payload_bytes=payload_bytes,seconds=len(seqs)*.020,mono=sum(n for t,n in toc.items() if t&4==0),stereo=sum(n for t,n in toc.items() if t&4),toc_histogram=dict(sorted(toc.items())),sha256=hashlib.sha256((out/'packets.bin').read_bytes()).hexdigest(),source_wav_sha256=hashlib.sha256(wav.read_bytes()).hexdigest(),sipbot_sha256=hashlib.sha256(sipbot.read_bytes()).hexdigest())
(out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
