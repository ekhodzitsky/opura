# Inputs for the SIP decoder profile

The workload uses the caller's negotiated Opus stream from the RustPBX SIP scenario. The historical tests saved RTP headers and counters. To reproduce the caller's encoded audio, a fresh copy of the pinned sipbot 0.2.82 transmitted the same source to a dedicated loopback UDP receiver. The SDP answer advertises the same PT 111 Opus 48 kHz/2 mapping, 10 ms minimum packet time, stereo and in-band FEC parameters as RustPBX 0.5.0. The sender generated mono Hybrid fullband 20 ms packets throughout. This receipt concerns the forward Opus decoder input only. It excludes the echo encoder, SIP signaling and jitter from the timed packet replay.

Build the pinned loopback-enabled sipbot with the RustPBX SIP reproduction bundle. The original workstation binary SHA-256 was 63316b83d01d57bd3bb7528bf6e3fbc7fa13732af16aa90144cb6810c9d70624. Save the RustPBX public Mandarin WAV and the AMI Consortium's ES2002a mixed-headset WAV using their pinned URLs in the input receipt. Use Python 3.11+, bubblewrap, an available CPU and an empty working directory. Paths passed to the isolated receiver must be visible in its read-only root bind; its selected output directory is writable.

    python3 prepare_ami.py /path/to/ES2002a.Mix-Headset.wav ami-345.wav
    work_dir=$(pwd)
    bwrap --unshare-net --unshare-pid --die-with-parent --ro-bind / / --bind "$work_dir" "$work_dir" --proc /proc --dev /dev -- python3 receive.py /path/to/sipbot /path/to/speech.wav mandarin --tail 1
    bwrap --unshare-net --unshare-pid --die-with-parent --ro-bind / / --bind "$work_dir" "$work_dir" --proc /proc --dev /dev -- python3 receive.py /path/to/sipbot ami-345.wav ami --tail 1 --expected-wav 8572e076377a2d6832a76c459a6b9acf36bd66b02cf18dcb7ef723a92d4c0825
    python3 qualify.py mandarin/packets.bin
    python3 qualify.py ami/packets.bin

Each packets.bin holds 1600 packets of a single continuous 32 s stream, each prefixed by a 4-byte big-endian payload length. Every recorded RTP sequence increments by 1 and each timestamp increments by 960 on the 48 kHz clock. The extra call second allows asynchronous teardown while the receiver keeps only the first 1600 packets. External libopus 1.6.1 independently checked every payload's size, mono channel count, bandwidth, sample duration, frame count and final-range state. The receiver uses only a dedicated loopback endpoint receiving a public speech source, and the codec build and ordinary tests do not use this program.
