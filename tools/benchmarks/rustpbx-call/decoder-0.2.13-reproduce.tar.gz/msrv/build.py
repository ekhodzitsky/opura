"""Build the pure core-only replay using the ordinary opt-level 3 release profile."""
import json
from pathlib import Path
import shutil
import subprocess
import sys
r = Path(__file__).resolve().parent
arm = sys.argv[1]
assert arm in ('base','candidate')
dep = 'version="=0.2.12"' if arm == 'base' else 'path='+json.dumps(str(Path(sys.argv[2]).resolve()))
project = r/('build-'+arm)
(project/'src').mkdir(parents=True,exist_ok=True)
(project/'Cargo.toml').write_text('[package]\nname="msrv-replay"\nversion="0.0.0"\nedition="2021"\n[dependencies]\nopura={'+dep+'}\n')
shutil.copyfile(r/'worker.rs',project/'src/main.rs')
subprocess.run(['cargo','+1.87.0','build','--release','--offline'],cwd=project,check=True)
(r/'bin').mkdir(exist_ok=True)
shutil.copy2(project/'target/release/msrv-replay',r/'bin'/arm)
