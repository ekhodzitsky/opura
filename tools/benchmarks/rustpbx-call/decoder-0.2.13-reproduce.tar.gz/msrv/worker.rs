use std::{env,fs,hint::black_box,io::Write};
fn packets(path: &str) -> Vec<Vec<u8>> {
    let b=fs::read(path).unwrap();
    let mut s=&b[..];
    let mut result=Vec::new();
    while !s.is_empty(){
        let len=u32::from_be_bytes(s[..4].try_into().unwrap()) as usize;
        result.push(s[4..4+len].to_vec());s=&s[4+len..];
    }
    assert!(!result.is_empty());result
}
fn cpu() -> u64 { fs::read_to_string("/proc/thread-self/schedstat").unwrap().split_whitespace().next().unwrap().parse().unwrap() }
fn emit(out: &[i16], dump: &mut Option<std::io::BufWriter<fs::File>>){
    if let Some(w)=dump {
        for &x in out { w.write_all(&x.to_le_bytes()).unwrap(); }
    }
    black_box(out);
}
fn core(p:&[Vec<u8>], dump:&mut Option<std::io::BufWriter<fs::File>>){
    use opura::{decoder::CompactOpusDecoder as D,silk::{resampler::OutputRate,decoder::PcmChannels as C}};
    let make=|c| D::new(OutputRate::Khz48,if c==2 {C::Stereo} else {C::Mono}).unwrap();
    let mut channels=1;
    let mut d=make(channels);
    let mut out=[0i16;1920];
    for packet in p {
        let c=if packet[0]&4!=0 {2} else {1};
        if c!=channels{ d=make(c);channels=c; }
        let n=d.decode_into(black_box(packet),&mut out).unwrap();
        emit(&out[..n],dump);
    }
}
fn main(){
    let a=env::args().collect::<Vec<_>>();let pkts=packets(&a[1]);
    assert_eq!(a[2], "core");let f=core;
    let repeats: usize=a[3].parse().unwrap();
    let mut dump=a.get(4).map(|p|std::io::BufWriter::new(fs::File::create(p).unwrap()));
    f(&pkts,&mut dump);drop(dump);
    let before=cpu(); for _ in 0..repeats{ f(&pkts,&mut None); } println!("{}",cpu()-before);
}
