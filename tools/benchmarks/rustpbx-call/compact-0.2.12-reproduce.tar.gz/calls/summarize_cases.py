"""Report paired steady PBX CPU/RSS and endpoint delivery; run where the campaign was collected."""
from pathlib import Path
import hashlib
import json
import math
import statistics as st
import sys

r=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'../qa'))
from rtp_stats import summarize as rtp
def read(path):return json.loads(path.read_text())
def reduce():
    cases=read(r/'completed.json')
    receipt={'cases':[],'primary':{},'paired':{},'temporal_endpoints':'Whole observed call life; RTP receive intervals at sipbot endpoints; 20ms nominal cadence.'}
    for trial in cases:
        d=r/trial['case']
        if not (d/'result.json').exists():
            receipt['cases'].append(trial)
            continue
        result=read(d/'result.json')
        accepted={k:v for k,v in result.items() if k not in {'samples','wall_origin_s','monotonic_origin_ns','bridge_intervals_s'}}
        accepted.update(trial,late_bridge_established_s=max(x[0] for x in result['bridge_intervals_s']),first_bridge_hangup_s=min(x[1] for x in result['bridge_intervals_s']))
        accepted['rss_mib']=result['rss_kib']/1024
        accepted['private_dirty_mib']=result['private_dirty_kib']/1024
        accepted['rss_growth_mib']=(result['rss_kib']-result['idle_kib']['rss'])/1024
        accepted['coverage']=read(d/'coverage.json')
        accepted['rtp']={}
        for side in ['uac','uas']:
            path=d/(side+'.rtpbin')
            stats=rtp(path)
            accepted['rtp'][side]=stats['total']
            accepted['rtp'][side]['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
            accepted['rtp'][side]['flow_count']=len(stats['streams'])
        receipt['cases'].append(accepted)
    valid=[c for c in receipt['cases'] if c['case'].startswith('primary-') and c['qualified']]
    for arm in ['stock','opura']:
        rows=[x for x in valid if x['arm']==arm]
        if not rows:continue
        armstats={'qualifying_processes':len(rows)}
        for key in ['cpu_cores','rss_mib','rss_growth_mib','private_dirty_mib']:
            armstats[key]=st.median(x[key] for x in rows)
        armstats['rtp']={}
        for side in ['uac','uas']:
            m=[row['rtp'][side] for row in rows]
            side_summary={k:sum(x[k] for x in m) for k in ['packets','intervals','missing_in_bounds','reordered','duplicates','gt40ms','gt100ms']}
            side_summary['median_process_p99_ms']=st.median(x['spacing_p99_ns']/1e6 for x in m)
            side_summary['maximum_ms']=max(x['max_spacing_ns']/1e6 for x in m)
            armstats['rtp'][side]=side_summary
        receipt['primary'][arm]=armstats
    groups={p:{x['arm']:x for x in valid if x['case'].split('-')[1]==str(p)} for p in range(1,5)}
    whole={p:g for p,g in groups.items() if len(g)==2}
    if whole:
        ratios=[g['opura']['cpu_cores']/g['stock']['cpu_cores'] for g in whole.values()]
        receipt['paired']={'qualifying_pairs':list(whole),'cpu_geometric_ratio':math.exp(st.mean(map(math.log,ratios))),'cpu_ratios':ratios,
            'rss_delta_mib':[g['opura']['rss_mib']-g['stock']['rss_mib'] for g in whole.values()],
            'rss_growth_delta_mib':[g['opura']['rss_growth_mib']-g['stock']['rss_growth_mib'] for g in whole.values()]}
    (r/'summary.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'primary':receipt['primary'],'pair':receipt['paired']},indent=2))
if __name__=='__main__':reduce()
