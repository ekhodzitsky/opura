"""Measure one fresh RustPBX server with real registered loopback endpoints."""
import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import socket
import statistics
import subprocess
import time
import wave
from base_call import create_input, rx_tone, sample, wait_health


def classify(log_path):
    lines = log_path.read_text(errors='replace').splitlines()
    totals = [line for line in lines if 'Avg Loss:' in line]
    if not totals:
        raise ValueError('Missing sipbot endpoint summary')
    line = totals[-1]
    packets = re.search(r'TX: (\d+)p/(\d+)b, RX: (\d+)p/(\d+)b', line)
    done = re.search(r'Progress: (\d+)/(\d+) \(Current: (\d+)\)', line)
    statuses = re.search(r'Status: \[([^\]]+)\]', line)
    duration = re.search(r'Avg Duration: ([\d.]+)s', line)
    loss = re.search(r'Avg Loss: ([\d.]+)%', line)
    assert all([packets, done, statuses, duration, loss]), line
    return dict(completed=int(done[1]), attempted=int(done[2]),
                status={s:int(n) for s,n in re.findall(r'(\d+):(\d+)',statuses[1])},
                tx_packets=int(packets[1]), rx_packets=int(packets[3]),
                tx_bytes=int(packets[2]), rx_bytes=int(packets[4]),
                mean_call_seconds=float(duration[1]), avg_loss_pct=float(loss[1]),
                has_audio='has_audio=true' in line)


def run():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('root',type=Path)
    ap.add_argument('backend',choices=['stock','opura'])
    ap.add_argument('case')
    ap.add_argument('--calls',type=int,default=16)
    ap.add_argument('--seconds',type=int,default=32)
    ap.add_argument('--cps',type=int,default=2)
    ap.add_argument('--steady',nargs=2,type=float,default=(10,29))
    ap.add_argument('--meter',type=Path)
    args=ap.parse_args()
    if {name for _,name in socket.if_nameindex()}!={'lo'}:
        raise RuntimeError('This workload requires isolated loopback')
    root=args.root.resolve()
    case=root/args.case
    case.mkdir()
    cfg=Path(__file__).with_name('site.toml').read_text()
    (case/'site.toml').write_text(cfg.replace('sqlite://pbx.sqlite','sqlite://'+str(case/'pbx.sqlite')))
    if args.calls==1:
        sound=create_input(root,case,1)
    else:
        sound=case/'input.wav'
        with wave.open(str(root/'speech.wav'),'rb') as source,wave.open(str(sound),'wb') as out:
            out.setparams(source.getparams())
            pcm=source.readframes(source.getnframes())
            out.writeframes(pcm*(1+((args.seconds+1)*source.getframerate()//source.getnframes())))
    children=[]
    def launch(name,command,cpus):
        env={**os.environ,'TZ':'UTC'}
        if name in ('uas','uac') and args.meter:
            command=['env','LD_PRELOAD='+str(args.meter.resolve()), 'SIP123_RTP_LOG='+str(case/(name+'.rtpbin')),*command]
        with (case/(name+'.log')).open('wb') as log:
            cmd=['taskset','-c',cpus,*command]
            proc=subprocess.Popen(cmd,cwd=case,stdout=log,stderr=subprocess.STDOUT,env=env)
        children.append(proc)
        return proc
    result=dict(arm=args.backend, calls=args.calls, seconds=args.seconds,cps=args.cps,
                steady_seconds=list(args.steady), server_cpus=[4,5,6,7], client_cpus=[8,9,10,11], tick_hz=os.sysconf('SC_CLK_TCK'))
    try:
        srv=launch('server',[root/args.backend,'--conf',case/'site.toml'],'4-7')
        wait_health(srv)
        client=[root/'sipbot','--conf',case/'unused.toml']
        account=['--password','smoke-only','--register','127.0.0.1:15061']
        common=['--audio-quality','-v']
        def recording(name):
            return ['--record',case/(name+'.wav')] if args.calls==1 else []
        uas=launch('uas',client+['wait','--username','bob',*account,'--addr','127.0.0.1:15090','--codecs','pcmu','--echo','--hangup',str(args.seconds+12),*common,*recording('bob')],'8-11')
        for _ in range(75):
            if uas.poll() is not None: raise RuntimeError('echo endpoint exited early')
            if 'Registered successfully' in (case/'uas.log').read_text(errors='replace'): break
            time.sleep(.1)
        else: raise RuntimeError('Timed out registering echo endpoint')
        idle=sample(srv.pid)
        origin=time.monotonic()
        result['monotonic_origin_ns']=int(origin*1e9)
        uac=launch('uac',client+['call','--target','sip:bob@127.0.0.1:15061','--username','alice',*account,'--addr','127.0.0.1:15091','--codecs','opus','--hangup',str(args.seconds),'--total',str(args.calls),'--cps',str(args.cps),'--play',sound,*common,*recording('alice')],'8-11')
        result['wall_origin_s']=time.time()
        observations=[]
        deadline=origin+args.seconds+args.calls/args.cps+20
        while uac.poll() is None and time.monotonic()<deadline:
            stamp,cpu,rss,pd=sample(srv.pid)
            observations.append([stamp-origin,cpu,rss,pd])
            time.sleep(.25)
        result['caller_exit']=uac.poll()
        # The UAS emits a fresh summary each second. Wait only for the final one.
        for _ in range(30):
            text=(case/'uas.log').read_text(errors='replace')
            if re.search(r'Progress: '+str(args.calls)+'/'+str(args.calls)+r' \(Current: 0\)',text): break
            time.sleep(.1)
        result['idle_kib']={'rss':idle[2],'private_dirty':idle[3]}
        result['samples']=observations
        plateau=[x for x in observations if args.steady[0]<=x[0]<=args.steady[1]]
        assert len(plateau)>=2
        result['cpu_cores']=(plateau[-1][1]-plateau[0][1])/result['tick_hz']/(plateau[-1][0]-plateau[0][0])
        result['rss_kib']=statistics.median(x[2] for x in plateau)
        result['private_dirty_kib']=statistics.median(x[3] for x in plateau)
        result['sampled_live_peak_kib']=max(x[2] for x in plateau)
    finally:
        for proc in reversed(children):
            if proc.poll() is None:
                proc.send_signal(signal.SIGINT)
                try:proc.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    proc.terminate()
                    try:proc.wait(timeout=2)
                    except subprocess.TimeoutExpired:proc.kill();proc.wait()
    for side in ('uac','uas'):
        result[side]=classify(case/(side+'.log'))
    log=(case/'server.log').read_text(errors='replace')
    result['unique_bridges']=len(set(re.findall(r'transcoding activated session=(\S+) a_codec=Opus b_codec=PCMU has_webrtc_leg=false',log)))
    begins={};ends={}
    for line in log.splitlines():
        act=re.search(r'transcoding activated session=(\S+) a_codec=Opus b_codec=PCMU has_webrtc_leg=false',line)
        end=re.search(r'Caller initiated hangup \(UacBye\) session_id=(\S+)',line)
        if act or end:
            elapsed=datetime.fromisoformat(line.split()[0]).timestamp()-result['wall_origin_s']
            if act: begins[act[1]]=elapsed
            if end: ends[end[1]]=elapsed
    common_ids=begins.keys() & ends.keys()
    result['bridge_intervals_s']=sorted([[begins[k],ends[k]] for k in common_ids])
    result['all_bridges_steady']=len(common_ids)==args.calls and all(b<=args.steady[0] and e>=args.steady[1] for b,e in result['bridge_intervals_s'])
    result['plateau_progress_observed']=bool(re.search(r'Progress: 0/'+str(args.calls)+', Active: '+str(args.calls)+', 200: '+str(args.calls)+',', (case/'uac.log').read_text(errors='replace')))
    checks=[result['caller_exit']==0, result['unique_bridges']==args.calls,result['plateau_progress_observed'],result['all_bridges_steady']]
    for side in ('uac','uas'):
        e=result[side]
        checks.extend([e['completed']==args.calls,e['attempted']==args.calls,e['status']=={'200':args.calls},e['has_audio'],e['rx_packets']>=.98*args.calls*args.seconds*50,e['tx_packets']>=.98*args.calls*args.seconds*50])
    if args.calls==1:
        for side in ('bob','alice'):
            recordings=list(case.glob(side+'*.wav')); assert len(recordings)==1
            result[side+'_tone']=rx_tone(recordings[0])
            t=result[side+'_tone']; checks.append(t['tone_windows']>=.95*(args.seconds*4))
    result['qualified']=all(checks)
    (case/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(args.case,'qualified',result['qualified'],'bridges',result['unique_bridges'],result['uac']['status'],result['uas']['status'],result['cpu_cores'],result['rss_kib'],flush=True)
    # A failed case remains on disk and can be inspected instead of being silently retried.
    if not result['qualified']:raise SystemExit(2)

if __name__=='__main__':run()
