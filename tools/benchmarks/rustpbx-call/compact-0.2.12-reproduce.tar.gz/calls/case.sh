#!/bin/sh
set -eu
r=$(dirname "$(realpath "$0")")
exec bwrap --unshare-net --unshare-pid --die-with-parent --ro-bind / / --bind "$r" "$r" --proc /proc --dev /dev -- taskset -c 2 python3 "$r/call_case.py" "$r" "$@"
