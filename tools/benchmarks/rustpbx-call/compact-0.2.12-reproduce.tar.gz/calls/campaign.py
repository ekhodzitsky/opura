"""Run one retained, counterbalanced SIP campaign; execute from the workload directory."""
from pathlib import Path
import hashlib, json, struct, subprocess, sys, time

r=Path(__file__).resolve().parent
meter=(r/'../qa/rtp_meter.so').resolve()
p=json.loads((r/'protocol.json').read_text())
def digest(f):
    return hashlib.sha256(f.read_bytes()).hexdigest()
def coverage(path, t0, lo, hi, nominal_pt):
    rec=struct.Struct('<QIIHHHBB'); group={}
    for t,ts,ssrc,seq,port,fd,pt,m in rec.iter_unpack(path.read_bytes()):
        if pt!=nominal_pt: raise ValueError('Unexpected media payload type')
        key=port,fd,ssrc,pt
        if key not in group:group[key]=[0,0,0]
        g=group[key];g[0]+=1
        elapsed=(t-t0)/1e9
        if lo<=elapsed<=hi:g[1]+=1
        if g[0]==1:g.append(elapsed)
        g[2]=elapsed
    return {'flow_count':len(group),'flow_rx_packets':sorted(g[0] for g in group.values()),
            'flow_packets_during_plateau':sorted(g[1] for g in group.values()),
            'last_first_rx_seconds':max((g[3] for g in group.values()),default=None),
            'first_last_rx_seconds':min((g[2] for g in group.values()),default=None)}
def run_case(phase, pair, arm):
    opt=p[phase]; name=f'{phase}-{pair}-{arm}'; d=r/name
    cmd=[r/'case.sh',arm,name,'--calls',str(opt['calls']),'--seconds',str(opt['seconds']),
         '--cps',str(opt['cps']),'--steady',*map(str,opt['steady_seconds']),'--meter',meter]
    if d.exists():raise ValueError('Refusing to replace observation '+name)
    run=subprocess.run(cmd, timeout=opt['seconds']+opt['calls']/opt['cps']+48,
                       capture_output=True,text=True)
    (d/'exit.txt').write_text(str(run.returncode)+'\n'+run.stdout+run.stderr)
    result={'case':name,'exit':run.returncode,'qualified':False}
    if (d/'result.json').exists():
        raw=json.loads((d/'result.json').read_text());result['qualified']=raw['qualified']
        proof={}; lo,hi=opt['steady_seconds']
        for side,pt in [('uas',0),('uac',111)]:
            s=coverage(d/(side+'.rtpbin'),raw['monotonic_origin_ns'],lo,hi,pt)
            s['all_flows_active_in_window']=(s['flow_count']==opt['calls'] and min(s['flow_packets_during_plateau'],default=0)>=(hi-lo)*50*.98 and s['last_first_rx_seconds']<=lo and s['first_last_rx_seconds']>=hi)
            result['qualified'] &= s['all_flows_active_in_window']
            proof[side]=s
        (d/'coverage.json').write_text(json.dumps(proof,indent=2)+'\n')
    print(name,result,flush=True)
    return result
def main():
    ids={v:digest(r/v) for v in ['stock','opura','sipbot','speech.wav','protocol.json','call_case.py']}
    with (r/'timed-binaries.json').open('x') as out:json.dump(ids,out,indent=2)
    trials=[]
    for phase in ['primary','secondary']:
        if phase=='secondary' and not all(x['qualified'] for x in trials):break
        for i,pair in enumerate(p[phase]['pairs'],1):
            for arm in pair:
                trials.append(run_case(phase,i,arm))
                (r/'completed.json').write_text(json.dumps(trials,indent=2)+'\n')
if __name__=='__main__':main()
