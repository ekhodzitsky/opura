"""Reduce metadata from the isolated reference caller/echo process on little-endian Linux."""
from collections import Counter, defaultdict
import json
import math
from pathlib import Path
import statistics
import struct
import sys

RECORD = struct.Struct("<QIIHHHBB")

def percentile(numbers, p):
    ordered = sorted(numbers)
    return ordered[max(0, math.ceil(len(ordered)*p)-1)]

def summarize(path):
    streams = defaultdict(list)
    for clock, ts, ssrc, sequence, port, fd, pt, marker in RECORD.iter_unpack(path.read_bytes()):
        streams[port, fd, ssrc, pt].append((clock, sequence, ts))
    aggregates = []
    all_intervals = []
    for (_, _, _, pt), packets in sorted(streams.items(), key=lambda item: min(p[0] for p in item[1])):
        packets.sort()
        base = high = packets[0][1]
        sequences = {}
        first_mono = None
        gaps = []
        duplicates = reordered = 0
        for mono, seq, ts in packets:
            if first_mono is not None:
                gaps.append(mono - first_mono)
            first_mono = mono
            unwrapped = high + ((seq - high + 32768) % 65536) - 32768
            if unwrapped in sequences: duplicates += 1
            elif unwrapped < high: reordered += 1
            sequences.setdefault(unwrapped, ts)
            high = max(unwrapped, high)
            base = min(unwrapped, base)
        # Bound by observed endpoint sequence numbers. Unknown stream start/end excluded.
        timestamp_steps = Counter()
        for seq, ts in sequences.items():
            if seq-1 in sequences:
                timestamp_steps[(ts-sequences[seq-1])%(1<<32)] += 1
        temporal = {}
        if gaps:
            temporal = dict(intervals=len(gaps), spacing_p50_ns=percentile(gaps,.5), spacing_p95_ns=percentile(gaps,.95),
                            spacing_p99_ns=percentile(gaps,.99), max_spacing_ns=max(gaps),
                            gt20ms=sum(x>20_000_000 for x in gaps), gt40ms=sum(x>40_000_000 for x in gaps),
                            gt60ms=sum(x>60_000_000 for x in gaps), gt100ms=sum(x>100_000_000 for x in gaps))
        aggregates.append(dict(stream=len(aggregates)+1, pt=pt, packets=len(packets), bounds_span=high-base+1,
                               unique=len(sequences), missing_in_bounds=high-base+1-len(sequences), reordered=reordered,
                               duplicates=duplicates, consecutive_timestamp_steps=dict(sorted(timestamp_steps.items())),
                               receive_span_ns=packets[-1][0]-packets[0][0], **temporal))
        all_intervals.extend(gaps)
    cols = ['packets','bounds_span','unique','missing_in_bounds','reordered','duplicates','intervals','gt20ms','gt40ms','gt60ms','gt100ms']
    total={k:sum(s.get(k,0) for s in aggregates) for k in cols}
    if all_intervals:
        total.update(spacing_p50_ns=percentile(all_intervals,.50),spacing_p95_ns=percentile(all_intervals,.95),
                     spacing_p99_ns=percentile(all_intervals,.99),spacing_p999_ns=percentile(all_intervals,.999),
                     max_spacing_ns=max(all_intervals))
    return dict(streams=aggregates, total=total)

if __name__ == '__main__':
    print(json.dumps(summarize(Path(sys.argv[1])),indent=2))
