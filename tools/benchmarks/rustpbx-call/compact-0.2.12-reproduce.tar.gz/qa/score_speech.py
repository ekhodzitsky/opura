"""Verify received public speech by aligned 20-ms RMS envelopes; no waveform is persisted."""
from array import array
import json
import math
import statistics
import sys
import wave
from pathlib import Path


def envelope(path, channels):
    with wave.open(str(path)) as reader:
        assert reader.getframerate() == 16000 and reader.getsampwidth() == 2
        assert reader.getnchannels() == channels
        data = array('h', reader.readframes(reader.getnframes()))
        if sys.byteorder != 'little':
            data.byteswap()
    data = data[::channels]  # sipbot RX/left
    return [math.log1p(math.sqrt(sum(s*s for s in data[i:i+320])/320)/100.)
            for i in range(0, len(data)-319, 320)]


def best_cyclic_correlation(reference, observed):
    # Fold repeats of the source period before trying alignment offsets.
    count = len(reference)
    n = len(observed)
    folded = [0.0] * count
    weights = [0] * count
    for i, value in enumerate(observed):
        folded[i % count] += value
        weights[i % count] += 1
    y_mean = statistics.mean(observed)
    var_y = sum((v-y_mean)**2 for v in observed)
    best = (-1, None)
    for phase in range(count):
        template = reference[phase:]+reference[:phase]
        x_mean = sum(w*v for w,v in zip(weights,template))/n
        var_x = sum(w*(x-x_mean)**2 for w,x in zip(weights,template))
        xy = sum((x-x_mean)*(s-w*y_mean) for x,s,w in zip(template,folded,weights))
        score = xy/math.sqrt(var_x*var_y) if var_x and var_y else 0
        if score>best[0]:
            best = score,phase
    return best


def evaluate(source, folder):
    reference=envelope(source,1)
    assert len(reference)==272
    output={}
    for side in ['alice','bob']:
        files=sorted(folder.glob(side+'*.wav'))
        assert len(files)==2
        output[side]=[]
        for f in files:
            observed=envelope(f,2)
            assert len(observed)>=590
            sections=[observed[:len(reference)],observed[len(reference):len(reference)*2]]
            score,phase=best_cyclic_correlation(reference,observed)
            reverse, _=best_cyclic_correlation(reference[::-1],observed)
            sub_scores=[best_cyclic_correlation(reference,x)[0] for x in sections]
            output[side].append(dict(windows=len(observed),correlation=score,time_reversed_control=reverse,
                                     per_source_period=sub_scores,phase_20ms=phase,
                                     qualified=score>=.7 and score>=reverse+.15 and min(sub_scores)>=.65))
    return output

if __name__=='__main__':
    print(json.dumps(evaluate(Path(sys.argv[1]),Path(sys.argv[2])),indent=2))
