from collections import defaultdict
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
import sys
from rtp_stats import RECORD, summarize

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def audit(case):
    d=json.loads((case/"result.json").read_text())
    calls=d["calls"]
    begin,end=d["steady_seconds"]
    samples=[s for s in d['samples'] if begin<=s[0]<=end]
    assert all(b[0]>a[0] and b[1]>=a[1] and b[2]>=b[3] for a,b in zip(samples,samples[1:]))
    assert samples[-1][0]-samples[0][0] >= end-begin-.8
    ticks=samples[-1][1]-samples[0][1]
    cpu=ticks/(samples[-1][0]-samples[0][0])/d['tick_hz']
    rss=statistics.median(row[2] for row in samples)
    private=statistics.median(row[3] for row in samples)
    peak=max(row[2] for row in samples)
    assert math.isclose(cpu,d['cpu_cores']) and rss==d['rss_kib'] and private==d['private_dirty_kib'] and peak==d['sampled_live_peak_kib']
    temporal_start,temporal_end={},{}
    health_lines=0
    for line in (case/'server.log').read_text(errors='replace').splitlines():
        a=re.search(r'transcoding activated session=(\S+) a_codec=Opus b_codec=PCMU has_webrtc_leg=false',line)
        b=re.search(r'Caller initiated hangup \(UacBye\) session_id=(\S+)',line)
        if a: temporal_start[a.group(1)]=datetime.fromisoformat(line.split()[0]).timestamp()-d['wall_origin_s']
        if b: temporal_end[b.group(1)]=datetime.fromisoformat(line.split()[0]).timestamp()-d['wall_origin_s']
    overlap = {k for k,stime in temporal_start.items() if stime<=begin and temporal_end.get(k,0)>=end}
    base = dict(case=case.name,arm=d['arm'],offered_calls=calls,seconds=d['seconds'],window=[begin,end],
                bridge_starts=len(temporal_start),bridge_finishes=len(temporal_end),bridges_covering_plateau=len(overlap),
                cpu_cores=cpu,steady_clock_ticks=ticks,steady_seconds=samples[-1][0]-samples[0][0],endpoints={},rss_kib=rss,
                private_dirty_kib=private,maximum_sampled_plateau_rss_kib=peak,plateau_samples=len(samples),
                data_sha256={'result':sha(case/'result.json')})
    origin=d['monotonic_origin_ns']
    for side,pt,step in [('uac',111,960),('uas',0,160)]:
        path=case/(side+'.rtpbin')
        a=summarize(path)
        flowtime={}
        for n,ts,ssrc,seq,port,fd,kind,marker in RECORD.iter_unpack(path.read_bytes()):
            key=ssrc,port,fd,kind
            if key not in flowtime: flowtime[key]=[n,n]
            else: flowtime[key]=[min(flowtime[key][0],n),max(flowtime[key][1],n)]
        assert all(s['pt']==pt for s in a['streams'])
        latest_start=max(st for st,en in flowtime.values())-origin
        earliest_end=min(en for st,en in flowtime.values())-origin
        active_flows=sum(st<=origin+begin*1e9 and en>=origin+end*1e9 for st,en in flowtime.values())
        timestamp_anomalies=sum(sum(v for k,v in s['consecutive_timestamp_steps'].items() if k!=step) for s in a['streams'])
        t=(case/(side+'.log')).read_text(errors='replace')
        summary=[ln for ln in t.splitlines() if 'Avg Loss:' in ln][-1]
        traffic=re.search(r'TX: (\d+)p/(\d+)b, RX: (\d+)p/(\d+)b',summary); assert traffic
        assert int(traffic[3])==d[side]['rx_packets'] and int(traffic[1])==d[side]['tx_packets']
        a.update(flows=len(flowtime),flows_covering_plateau=active_flows,latest_first_packet_s=latest_start/1e9,
                 earliest_last_packet_s=earliest_end/1e9,irregular_rtp_media_clock_steps=timestamp_anomalies,
                 sipbot_rx=d[side]['rx_packets'],sipbot_tx=d[side]['tx_packets'],sip200=d[side]['status'].get('200',0),
                 capture_minus_sipbot_rx=a['total']['packets']-d[side]['rx_packets'],registered='Registered successfully' in t)
        base['endpoints'][side]=a
        base['data_sha256'][side+'_rtp_metadata']=sha(path)
    base['qualified']=bool(d.get('qualified') and len(overlap)==calls and all(s['sip200']==calls and s['flows_covering_plateau']==calls and s['registered'] for s in base['endpoints'].values()))
    return base

if __name__=='__main__':
    print(json.dumps(audit(Path(sys.argv[1])),indent=2))
