/* Test-only observer for the synthetic SIP endpoints inside an isolated loopback namespace. */
#define _GNU_SOURCE
#include <arpa/inet.h>
#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <net/if.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

struct record {
    uint64_t mono_ns;
    uint32_t timestamp, ssrc;
    uint16_t sequence, remote_port, socket_fd;
    uint8_t payload_type, marker;
};
_Static_assert(sizeof(struct record) == 24, "record layout");

static int output = -1;
static ssize_t (*next_recvfrom)(int, void *, size_t, int, struct sockaddr *, socklen_t *);
static ssize_t (*next_recvmsg)(int, struct msghdr *, int);
__attribute__((constructor)) static void start_meter(void) {
    next_recvfrom = dlsym(RTLD_NEXT, "recvfrom");
    next_recvmsg = dlsym(RTLD_NEXT, "recvmsg");
    const char *path = getenv("SIP123_RTP_LOG");
    if (!path || !next_recvfrom || !next_recvmsg || !*path) _exit(94);
    struct if_nameindex *interfaces = if_nameindex();
    if (!interfaces || !interfaces[0].if_index || strcmp(interfaces[0].if_name, "lo") || interfaces[1].if_index) _exit(95);
    if_freenameindex(interfaces);
    output = open(path, O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC | O_APPEND, 0600);
    if (output < 0) _exit(96);
}
static void record_rtp(int fd, const unsigned char *p, size_t length, const struct sockaddr *peer, size_t addr_len) {
    if (length < 12 || p[0] >> 6 != 2 || (p[1] >= 192 && p[1] <= 223)) return;
    if (!peer || addr_len < sizeof(struct sockaddr_in) || peer->sa_family != AF_INET) return;
    const struct sockaddr_in *v4 = (const struct sockaddr_in *)peer;
    if (ntohl(v4->sin_addr.s_addr) >> 24 != 127) return;
    struct timespec t;
    if (clock_gettime(CLOCK_MONOTONIC, &t)) _exit(97);
    uint16_t seq;
    uint32_t ts, ssrc;
    memcpy(&seq, p+2, 2);
    memcpy(&ts, p+4, 4);
    memcpy(&ssrc, p+8, 4);
    struct record r = {(uint64_t)t.tv_sec * 1000000000 + t.tv_nsec, ntohl(ts), ntohl(ssrc), ntohs(seq), ntohs(v4->sin_port), (uint16_t)fd, p[1]&127, p[1] >> 7};
    int saved = errno;
    ssize_t count;
    do { count = write(output, &r, sizeof(r)); } while (count < 0 && errno == EINTR);
    if (count != sizeof(r)) _exit(98);
    errno = saved;
}
ssize_t recvfrom(int fd, void *buf, size_t len, int flags, struct sockaddr *src, socklen_t *srclen) {
    ssize_t n = next_recvfrom(fd, buf, len, flags, src, srclen);
    if (n > 0 && !(flags & MSG_PEEK)) record_rtp(fd, buf, (size_t)n < len ? (size_t)n : len, src, srclen ? *srclen : 0);
    return n;
}
ssize_t recvmsg(int fd, struct msghdr *msg, int flags) {
    ssize_t n = next_recvmsg(fd, msg, flags);
    if (n >= 12 && !(flags & MSG_PEEK) && msg->msg_iovlen && msg->msg_iov[0].iov_len >= 12)
        record_rtp(fd, msg->msg_iov[0].iov_base, 12, msg->msg_name, msg->msg_namelen);
    return n;
}
