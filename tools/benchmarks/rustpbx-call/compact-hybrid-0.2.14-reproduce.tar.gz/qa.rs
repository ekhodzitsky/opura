use opura::{
    decoder::{CompactOpusDecoder,OpusDecoder,DecodedPcm},
    celt::decoder::CeltDecoder,
    silk::{decoder::PcmChannels,resampler::OutputRate},
};
use std::{env,fs,io::{self, BufWriter,Write}};

fn diagnostics(w:&mut impl Write, decoder:Option<&CeltDecoder>) {
    let Some(d)=decoder else {w.write_all(&[0]).unwrap();return};
    w.write_all(&[1,d.channels() as u8]).unwrap();
    let c=d.concealment();
    for i in [0,1] {
        let history:&[i32;2048]=c.history(i).unwrap();
        let future:&[i32;120]=c.future(i).unwrap();
        let coeff:&[i16;24]=c.coefficients(i).unwrap();
        if i==1 && d.channels()==1 {
            assert!(history.iter().all(|&x|x==0) && future.iter().all(|&x|x==0) && coeff.iter().all(|&x|x==0));
            assert!(d.synthesis().postfilter(1).is_none() && d.synthesis().overlap(1).is_none());
        }
        for x in history.iter().chain(future) {w.write_all(&x.to_le_bytes()).unwrap()}
        for x in coeff {w.write_all(&x.to_le_bytes()).unwrap()}
        if let Some(p)=d.synthesis().postfilter(i) {
            for x in p.history() {w.write_all(&x.to_le_bytes()).unwrap()}
        }
        if let Some(o)=d.synthesis().overlap(i) {
            for x in o {w.write_all(&x.to_le_bytes()).unwrap()}
        }
    }
    for x in d.synthesis().deemphasis_memory() {w.write_all(&x.to_le_bytes()).unwrap()}
}
fn pcm(w:&mut impl Write, samples:&[i16], range:u32) {
    w.write_all(&(samples.len() as u32).to_be_bytes()).unwrap();
    w.write_all(&range.to_be_bytes()).unwrap();
    for &x in samples {w.write_all(&x.to_le_bytes()).unwrap()}
}
fn owned(w:&mut impl Write, out:&DecodedPcm) {
    pcm(w,out.samples(),out.final_range());
}
fn fixed_d(d:&OpusDecoder)->Option<&CeltDecoder>{Some(d.celt())}
fn compact_d(d:&CompactOpusDecoder)->Option<&CeltDecoder>{d.celt()}

macro_rules! test {
    ($dec:ident,$inspect:ident,$packets:expr,$ch:expr,$w:expr,$extended:expr) => {{
        let mut de=$dec::new(OutputRate::Khz48,$ch).unwrap();
        let mut buf=[i16::MAX;11520];
        let mut count=0;
        for (i,packet) in $packets.iter().enumerate() {
            if $extended && i%127==126 {
                let clone=de.clone();
                buf.fill(i16::MAX);
                assert!(de.decode_into(packet,&mut buf[..1]).is_err());
                assert_eq!(buf[0],i16::MAX);
                assert_eq!(de,clone);
                assert!(de.conceal_samples(0).is_err());
                assert_eq!(de,clone);
                owned($w,&de.conceal_samples(960).unwrap());
                diagnostics($w,$inspect(&de));
            }
            if $extended && i%257==256 {
                let clone=de.clone();
                match de.decode_fec(packet,960) {
                    Ok(p)=>{owned($w,&p);diagnostics($w,$inspect(&de));},
                    Err(e)=>{assert_eq!(de,clone);let t=format!("{e:?}");$w.write_all(t.as_bytes()).unwrap();},
                }
            }
            if $extended && i%509==508 {
                de.set_gain_q8(-256);
                assert_eq!(de.gain_q8(),-256);
                de.reset();
                diagnostics($w,$inspect(&de));
                de.set_gain_q8(0);
            }
            buf.fill(i16::MAX);
            let n=de.decode_into(packet,&mut buf).unwrap();
            assert!(buf[n..].iter().all(|&x|x==i16::MAX));
            pcm($w,&buf[..n],de.final_range());
            count+=n;
            if $extended && i%101==0 {diagnostics($w,$inspect(&de));}
        }
        assert!(count>0);
        eprintln!("packets {} samples {count}",$packets.len());
    }};
}
fn main() {
    let a:Vec<_>=env::args().collect();
    let raw=fs::read(&a[1]).unwrap();
    let fmt=&a[2];
    let ch=match a[3].as_str() {"1"=>PcmChannels::Mono,"2"=>PcmChannels::Stereo,_=>panic!("channels")};
    let extended=a[5]=="extended";
    let mut s=&raw[..];let mut packets=Vec::new();
    while !s.is_empty() {
        let n=u32::from_be_bytes(s[..4].try_into().unwrap()) as usize;
        let prefix=match fmt.as_str() {"sip"=>4,"rfc"=>8,_=>panic!("format")};
        packets.push(&s[prefix..prefix+n]);s=&s[prefix+n..];
    }
    let mut out=BufWriter::new(io::stdout().lock());
    match a[4].as_str(){
        "fixed"=>test!(OpusDecoder,fixed_d,packets,ch,&mut out,extended),
        "compact"=>test!(CompactOpusDecoder,compact_d,packets,ch,&mut out,extended),
        _=>panic!("api"),
    }
    out.flush().unwrap();
}
