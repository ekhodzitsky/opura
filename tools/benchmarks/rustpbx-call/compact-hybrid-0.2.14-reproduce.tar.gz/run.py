import argparse,hashlib,json,random,statistics,math,subprocess
from pathlib import Path
p=Path(__file__).resolve().parent;day=p.parents[1]
plan=json.loads((p/'protocol.json').read_text())
parser=argparse.ArgumentParser()
parser.add_argument('--mandarin',type=Path,required=True)
parser.add_argument('--ami',type=Path,required=True)
args=parser.parse_args()
inputs={'mandarin':args.mandarin.resolve(),'ami':args.ami.resolve()}
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def call(arm,worker,*args):return subprocess.check_output(['taskset','-c',str(plan['cpu']),p/'bin'/(arm+'-'+worker),*map(str,args)],text=True)
def median(values):return statistics.median(values)
memory=[]
with (p/'memory.jsonl').open('x') as raw:
 for row in plan['memory']:
  assert sha(p/'first24.bin')==plan['memory_prefix_sha256']
  w=json.loads(call(row['arm'],'memory',row['streams'],p/'first24.bin'))
  assert w['samples']==row['streams']*24*960
  row={**row,**w};memory.append(row);raw.write(json.dumps(row)+'\n');raw.flush()
assert len(memory)==30 and len({r['hash'] for r in memory})==len({r['range_hash'] for r in memory})==1
summ={}
for n in [1,128,768]:
 summ[str(n)]={a:{m:{'warm':median(r['warm'][i] for r in memory if r['arm']==a and r['streams']==n),
 'warm_minus_before':median(r['warm'][i]-r['before'][i] for r in memory if r['arm']==a and r['streams']==n)} for i,m in enumerate(['rss_kib','private_dirty_kib'])} for a in ['base','candidate']}
saving=summ['768']['base']['private_dirty_kib']['warm']-summ['768']['candidate']['private_dirty_kib']['warm']
print('memory save',saving,'KiB',flush=True)
def interval(data):
 blocks=[statistics.fmean(data[i:i+2]) for i in range(0,len(data),2)]
 rng=random.Random(plan['seed'])
 draws=sorted(math.exp(statistics.fmean(rng.choices(blocks,k=len(blocks)))) for _ in range(50000))
 return math.exp(statistics.fmean(data)),[draws[1249],draws[48749]]
timing={}
for method,corpora in plan['timing'].items():
 for corpus,c in corpora.items():
  path=inputs[corpus];assert sha(path)==plan['inputs'][corpus]['sha256']
  pair=[];arms={'base':[],'candidate':[]}
  with (p/(method+'-'+corpus+'.jsonl')).open('x') as raw:
   for roundnum,order in enumerate(c['rounds'],1):
    outcome={}
    for arm in order:
     vals=list(map(int,call(arm,'timing',path,method,c['repeats']).splitlines()))
     if method=='cpu':
      assert len(vals)==1; v=vals[0]/c['repeats']
     else:
      assert len(vals)==1600*c['repeats'];v=sorted(vals)[math.ceil(len(vals)*0.99)-1]
     assert v>0
     row={'round':roundnum,'arm':arm,'value':v,'raw_ns':vals}
     raw.write(json.dumps(row)+'\n');raw.flush();outcome[arm]=v;arms[arm].append(v)
    pair.append(math.log(outcome['candidate']/outcome['base']))
  ratio,ci=interval(pair)
  medians={a:median(v) for a,v in arms.items()}
  medratio=medians['candidate']/medians['base']
  passed=(ratio<=plan['gate']['cpu_ratio_max'] and ci[1]<=plan['gate']['cpu_ratio_upper95_max']) if method=='cpu' else (ratio<=plan['gate']['p99_ratio_max'] and medratio<=plan['gate']['p99_ratio_max'] and ci[1]<=plan['gate']['p99_ratio_upper95_max'])
  timing[method+'-'+corpus]={'ratio':ratio,'ci':ci,'median_ratio':medratio,'median_ns':medians,'passed':passed}
  print(method,corpus,timing[method+'-'+corpus],flush=True)
result={'protocol':plan,'protocol_sha256':sha(p/'protocol.json'),'memory':summ,'memory_saving_kib':saving,'memory_gate':saving>=plan['gate']['warm_private_dirty_saving_kib_768'],'timing':timing,'source_sha256':{x:sha(p/x) for x in ['run.py','timing.rs','memory.rs','build.py','qa.py','qa.rs']},'binary_sha256':{x.name:sha(x) for x in (p/'bin').iterdir()}}
with (p/'public.json').open('x') as f:json.dump(result,f,indent=2)
print('all measurement gates pass',result['memory_gate'] and all(v['passed'] for v in timing.values()))
