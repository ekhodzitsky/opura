use opura::{decoder::CompactOpusDecoder as Decoder, silk::{decoder::PcmChannels, resampler::OutputRate}};
use std::{env,fs::{self,File},hint::black_box,io::{self,Read,Seek,SeekFrom},time::Instant};
fn packets(raw: &[u8]) -> Vec<&[u8]> {
    let mut s=raw;
    let mut packets=Vec::new();
    while !s.is_empty() {
        let n=u32::from_be_bytes(s[..4].try_into().unwrap()) as usize;
        let p=&s[4..4+n];
        assert_eq!(p[0],0x78);
        packets.push(p);
        s=&s[4+n..];
    }
    assert_eq!(packets.len(),1600);
    packets
}
fn cpu(clock:&mut File)->io::Result<u64> {
    let mut text=[0;128];
    clock.seek(SeekFrom::Start(0))?;
    let n=clock.read(&mut text)?;
    let first=std::str::from_utf8(&text[..n]).unwrap().split_whitespace().next().unwrap();
    Ok(first.parse().unwrap())
}
fn pass(packets: &[&[u8]], latency:&mut Option<Vec<u64>>) {
    let mut decoder=Decoder::new(OutputRate::Khz48,PcmChannels::Mono).unwrap();
    let mut out=[0i16;960];
    for p in packets {
        let start=latency.as_ref().map(|_|Instant::now());
        let n=decoder.decode_into(black_box(p),&mut out).unwrap();
        if let (Some(samples),Some(b))=(latency.as_mut(),start) {
            samples.push(b.elapsed().as_nanos().try_into().unwrap());
        }
        assert_eq!(n,960);
        black_box(&out[..n]);
        black_box(decoder.final_range());
    }
}
fn main() {
    let args:Vec<_>=env::args().collect();
    let raw=fs::read(&args[1]).unwrap();
    let packets=packets(&raw);
    let measure_latency=match args[2].as_str() {"cpu"=>false,"latency"=>true,_=>panic!("measurement")};
    let repeats:usize=args[3].parse().unwrap();
    let mut samples=measure_latency.then(||Vec::with_capacity(repeats*packets.len()));
    let mut clock=File::open("/proc/thread-self/schedstat").unwrap();
    pass(&packets,&mut None);
    let before=cpu(&mut clock).unwrap();
    for _ in 0..repeats { pass(&packets,&mut samples); }
    let elapsed=cpu(&mut clock).unwrap()-before;
    if let Some(samples)=samples {
        assert_eq!(samples.len(),repeats*packets.len());
        for x in samples {println!("{x}");}
    } else {
        println!("{elapsed}");
    }
}
