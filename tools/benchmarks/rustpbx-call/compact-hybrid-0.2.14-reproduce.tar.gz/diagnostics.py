"""Separate celt() hot read diagnostic, with its own worker binaries and paired process schedule."""
import argparse,hashlib,json,os,random,shutil,statistics,subprocess
from pathlib import Path
p=Path(__file__).resolve().parent;day=p.parents[1]
plan=json.loads((p/'protocol.json').read_text())
parser=argparse.ArgumentParser()
parser.add_argument('--source',type=Path,required=True)
parser.add_argument('--mandarin',type=Path,required=True)
args=parser.parse_args()
source=args.source.resolve()
mandarin=args.mandarin.resolve()
assert hashlib.sha256(mandarin.read_bytes()).hexdigest()==plan['inputs']['mandarin']['sha256']
bins={}
for arm in ['base','candidate']:
 b=p/('diag-build-'+arm)
 b.mkdir(exist_ok=True)
 dep='"=0.2.13"' if arm=='base' else '{path='+json.dumps(str(source.resolve()))+'}'
 (b/'Cargo.toml').write_text('[package]\nname="hybrid128diag"\nversion="0.0.0"\nedition="2021"\n[features]\ncompact=[]\n[dependencies]\nopura='+dep+'\n')
 (b/'src/bin').mkdir(parents=True,exist_ok=True)
 for stem,needle,insert in [
  ('memory','let range = decoder.final_range();','let range = decoder.final_range();\n            black_box(decoder.celt());'),
  ('timing','black_box(decoder.final_range());','black_box(decoder.final_range());\n        black_box(decoder.celt());')]:
  raw=(p/(stem+'.rs')).read_text();assert raw.count(needle)==1
  if stem=='timing':
   # CPU mode includes the diagnostic access; p99 mode isn't run here.
   pass
  (b/'src/bin'/(stem+'.rs')).write_text(raw.replace(needle,insert))
 subprocess.run(['cargo','+1.87.0','generate-lockfile','--offline'],cwd=b,check=True)
 subprocess.run(['taskset','-c','2,3','cargo','+1.87.0','build','--locked','--release','--offline','--features','compact'],cwd=b,env={**os.environ,'CARGO_TARGET_DIR':str(b/'target')},check=True)
 for stem in ['memory','timing']:
  file=p/'bin'/('diag-'+arm+'-'+stem);shutil.copy2(b/'target/release'/stem,file);bins[(arm,stem)]=file
rng=random.Random(60128)
rows=[];timing=[]
schedule=[]
for kind in ['memory','cpu']:
 for round_no in range(1,6):
  order=['base','candidate'];rng.shuffle(order)
  schedule.append(dict(kind=kind,round=round_no,arms=order))
assert len(schedule)==10
(p/'diag-protocol.json').write_text(json.dumps({'method':'read celt() after each decode via black_box; all other settings as normal qualification. 5 fresh paired memory rounds at 768 and 5 CPU pairs Mandarin; diagnostic only','schedule':schedule},indent=2))
for item in schedule:
 for arm in item['arms']:
  stem='memory' if item['kind']=='memory' else 'timing'
  args=['768',p/'first24.bin'] if stem=='memory' else [mandarin,'cpu','10']
  o=subprocess.check_output(['taskset','-c','4',bins[(arm,stem)],*map(str,args)],text=True)
  if stem=='memory':
   x=json.loads(o);assert x['samples']==768*24*960;rows.append(dict(round=item['round'],arm=arm,**x))
  else:timing.append(dict(round=item['round'],arm=arm,cpu_ns=int(o)))
assert len({r['hash'] for r in rows})==len({r['range_hash'] for r in rows})==1
summary={}
for arm in ['base','candidate']:
 rr=[r for r in rows if r['arm']==arm];tt=[x['cpu_ns']/10 for x in timing if x['arm']==arm]
 summary[arm]={'warm_rss_kib':statistics.median(x['warm'][0] for x in rr),'warm_private_dirty_kib':statistics.median(x['warm'][1] for x in rr),'median_cpu_ns_per_replay':statistics.median(tt)}
receipt={'memory':rows,'timing':timing,'summary':summary,'binary_sha256':{str(k):hashlib.sha256(v.read_bytes()).hexdigest() for k,v in bins.items()}}
(p/'diagnostic.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(summary,indent=2))
