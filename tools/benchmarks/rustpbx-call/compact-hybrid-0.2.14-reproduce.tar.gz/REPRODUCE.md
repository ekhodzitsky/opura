# Reproduce the Opura mono Hybrid memory result

Use Rust 1.87.0 and Python 3.11+ on x86-64 Linux. No audio, executables, or
third-party code is included. Obtain the two continuous SIP packet files
with the Opura 0.2.13 Hybrid SIP benchmark capture recipe. The independent
AMI source excerpt and Mandarin source URLs are documented in that report.
The input format and SHA-256 digests are in protocol.json. Obtain the official
RFC 8251 vector files from the released project's conformance procedure.
The matching individual .bit files must be extracted into one directory.

Run the commands from the extracted bundle directory:

    python3 prepare.py /path/to/mandarin.bin
    python3 build.py base
    python3 build.py candidate --source /path/to/opura-checkout
    python3 qa.py base --mandarin /path/to/mandarin.bin --ami /path/to/ami.bin --vectors /path/to/rfc-vectors
    python3 qa.py candidate --mandarin /path/to/mandarin.bin --ami /path/to/ami.bin --vectors /path/to/rfc-vectors
    python3 run.py --mandarin /path/to/mandarin.bin --ami /path/to/ami.bin

Baseline is crates.io Opura =0.2.13 and must already be cached for offline
building. The candidate source should match the hashes in manifest.json.
Both arms use the standard Cargo release profile and the same CPU. Allow
CPU4 (and its SMT sibling) to remain idle before timing; the selected CPU
must be available to the process.

The input workers compare PCM and final range traces and check all retained
streams in the memory test. CPU measures thread schedstat across ten whole
replays. Latency is per-packet wall duration measured separately with
Instant. p99 is nearest-rank per process, with instrumentation included.
The original baseline clock smoke showed coarse schedstat deltas for
individual packets. Each main timing phase performs 20 paired rounds,
with the order mirrored within adjacent pairs. 95% intervals use 50,000
resamples of mirrored blocks. The memory workload measures five fresh
pairs at each load, 1/128/768 streams, advancing each stream through the
first 24 consecutive packets and keeping all state live at the snapshot.
No CELT diagnostics are accessed in the primary memory/CPU/latency runs.
The separate QA diagnostic exercise verifies borrowed read access, reset,
PLC, FEC, error rollback, and mono channel-one zero state.

The optional diagnostic tradeoff is measured separately:

    python3 diagnostics.py --source /path/to/opura-checkout --mandarin /path/to/mandarin.bin

That worker accesses celt() after each packet and checks memory at 768
active streams. It performs only five paired rounds each for memory and
Mandarin CPU. The supplemental result is descriptive and was not an
acceptance gate. The portable scripts differ from the measured local
drivers only in explicit path arguments and input validation.
