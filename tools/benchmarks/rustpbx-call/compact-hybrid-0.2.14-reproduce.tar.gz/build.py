import argparse,json,os,subprocess,shutil
from pathlib import Path
p=Path(__file__).resolve().parent
a=argparse.ArgumentParser()
a.add_argument('arm',choices=['base','candidate'])
a.add_argument('--source',type=Path)
args=a.parse_args()
arm=args.arm
b=p/('build-'+arm)
b.mkdir(exist_ok=True)
dep='"=0.2.13"' if arm=='base' else '{path='+json.dumps(str(args.source.resolve()))+'}'
(b/'Cargo.toml').write_text('[package]\nname="hybrid128"\nversion="0.0.0"\nedition="2021"\n[features]\ncompact=[]\n[dependencies]\nopura='+dep+'\n')
(b/'src/bin').mkdir(parents=True,exist_ok=True)
for x in ['memory','timing','qa']:
 shutil.copyfile(p/(x+'.rs'),b/'src/bin'/(x+'.rs'))
subprocess.run(['cargo','+1.87.0','generate-lockfile','--offline'],cwd=b,check=True)
env={**os.environ,'CARGO_TARGET_DIR':str(b/'target')}
subprocess.run(['taskset','-c','2,3','cargo','+1.87.0','build','--locked','--release','--offline','--features','compact'],cwd=b,env=env,check=True)
bin=p/'bin'
bin.mkdir(exist_ok=True)
for x in ['memory','timing','qa']:
 shutil.copy2(b/'target/release'/x,bin/(arm+'-'+x))
