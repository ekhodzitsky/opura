#[cfg(feature = "compact")]
use opura::decoder::CompactOpusDecoder as Decoder;
#[cfg(not(feature = "compact"))]
use opura::decoder::OpusDecoder as Decoder;
use opura::silk::{decoder::PcmChannels, resampler::OutputRate};
use std::{error::Error, fs, hint::black_box, io::Write};
type Result<T> = std::result::Result<T, Box<dyn Error>>;
fn usage() -> Result<[u64; 2]> {
    let metrics = fs::read_to_string("/proc/self/smaps_rollup")?;
    let field = |key: &str| -> Result<u64> {
        let line = metrics
            .lines()
            .find_map(|s| s.strip_prefix(key))
            .ok_or("missing proc field")?;
        Ok(line
            .split_ascii_whitespace()
            .next()
            .ok_or("missing value")?
            .parse()?)
    };
    Ok([field("Rss:")?, field("Private_Dirty:")?])
}
fn main() -> Result<()> {
    let args: Vec<_> = std::env::args().collect();
    let count: usize = args[1].parse()?;
    assert!([1, 128, 768].contains(&count));
    let raw = fs::read(&args[2])?;
    let mut packets = Vec::new();
    let mut remaining = &raw[..];
    while !remaining.is_empty() {
        let n = u32::from_be_bytes(remaining[..4].try_into()?) as usize;
        assert!(n > 0 && remaining[4] == 0x78);
        packets.push(&remaining[4..4 + n]);
        remaining = &remaining[4 + n..];
    }
    assert_eq!(packets.len(), 24);
    let mut dump = args.get(3).map(fs::File::create).transpose()?;
    let mut output = [0i16; 960];
    let mut first = [0i16; 960];
    black_box(&mut first);
    black_box(&mut output);
    black_box(usage()?);
    let before = usage()?;
    let mut streams = Vec::with_capacity(count);
    for _ in 0..count {
        streams.push(Decoder::new(OutputRate::Khz48, PcmChannels::Mono)?);
    }
    let mut hash = 0xcbf29ce484222325u64;
    let mut range_hash = 0xcbf29ce484222325u64;
    let mut decoded = 0;
    for packet in packets {
        let mut first_range = 0;
        for (i, decoder) in streams.iter_mut().enumerate() {
            let n = decoder.decode_into(black_box(packet), &mut output)?;
            assert_eq!(n, 960);
            decoded += n;
            let range = decoder.final_range();
            if i == 0 {
                first_range = range;
                first.copy_from_slice(&output);
                for sample in output {
                    for b in sample.to_le_bytes() {
                        hash = (hash ^ u64::from(b)).wrapping_mul(0x100000001b3);
                    }
                    if let Some(f) = &mut dump {
                        f.write_all(&sample.to_le_bytes())?;
                    }
                }
                for b in range.to_be_bytes() {
                    range_hash = (range_hash ^ u64::from(b)).wrapping_mul(0x100000001b3);
                }
            } else {
                assert_eq!(first[..], output[..]);
                assert_eq!(range, first_range);
            }
        }
    }
    assert_eq!(decoded, 24 * count * 960);
    let warm = usage()?;
    black_box(&streams);
    println!("{{\"before\":{:?},\"warm\":{:?},\"samples\":{},\"decoder_bytes\":{},\"hash\":\"{:016x}\",\"range_hash\":\"{:016x}\"}}",before,warm,decoded,std::mem::size_of::<Decoder>(),hash,range_hash);
    Ok(())
}
