import argparse,hashlib,json,subprocess
from pathlib import Path
p=Path(__file__).resolve().parent; day=p.parents[1]
plan=json.loads((p/'protocol.json').read_text())
a=argparse.ArgumentParser();a.add_argument('arm',choices=['base','candidate'])
a.add_argument('--mandarin',type=Path,required=True)
a.add_argument('--ami',type=Path,required=True)
a.add_argument('--vectors',type=Path,required=True)
args=a.parse_args()
inputs={'mandarin':args.mandarin.resolve(),'ami':args.ami.resolve()}
manifest=json.loads((p/'manifest.json').read_text())
cases=[]
for k,item in plan['inputs'].items():
 path=inputs[k];assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256']
 for ch in [1,2]: cases.append((path,'sip',ch,'plain'))
for name,digest in manifest['vector_input_sha256'].items():
 v=args.vectors.resolve()/name
 assert hashlib.sha256(v.read_bytes()).hexdigest()==digest
 for ch in [1,2]:
  cases.append((v,'rfc',ch,'plain'))
  cases.append((v,'rfc',ch,'extended'))
results=[]
for path,fmt,ch,method in cases:
 for api in ['fixed','compact']:
  cmd=['taskset','-c','2',str(p/'bin'/(args.arm+'-qa')),str(path),fmt,str(ch),api,method]
  h=hashlib.sha256();n=0
  with subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE) as proc:
   for chunk in iter(lambda:proc.stdout.read(65536),b''):h.update(chunk);n+=len(chunk)
   info=proc.stderr.read().decode().strip()
   if proc.wait():raise RuntimeError((cmd,info))
  results.append(dict(input=path.name,format=fmt,channels=ch,method=method,api=api,sha256=h.hexdigest(),bytes=n,info=info))
  print(results[-1],flush=True)
receipt={'results':results,'binary_sha256':hashlib.sha256((p/'bin'/(args.arm+'-qa')).read_bytes()).hexdigest()}
if args.arm=='candidate':assert results==json.loads((p/'base-qa.json').read_text())['results'], 'baseline/candidate mismatch'
with (p/(args.arm+'-qa.json')).open('x') as f:json.dump(receipt,f,indent=2)
