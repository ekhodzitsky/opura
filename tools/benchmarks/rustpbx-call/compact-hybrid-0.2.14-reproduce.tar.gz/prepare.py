import argparse,hashlib,json
from pathlib import Path
p=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('mandarin',type=Path)
args=parser.parse_args()
plan=json.loads((p/'protocol.json').read_text())
raw=args.mandarin.read_bytes()
assert hashlib.sha256(raw).hexdigest()==plan['inputs']['mandarin']['sha256']
i=0
for _ in range(24):
 n=int.from_bytes(raw[i:i+4],'big')
 assert n>0 and raw[i+4]==0x78
 i+=4+n
prefix=raw[:i]
assert hashlib.sha256(prefix).hexdigest()==plan['memory_prefix_sha256']
(p/'first24.bin').write_bytes(prefix)
