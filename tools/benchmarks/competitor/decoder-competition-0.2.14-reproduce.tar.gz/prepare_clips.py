"""Recreate the packet payload source for Golos or the original Xiph music excerpt."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import wave

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("kind", choices=("golos", "music"))
parser.add_argument("source", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()

if args.output.exists():
    parser.error("Choose a new output path.")
if args.kind == "music":
    # Preserve the exact signed PCM frame sequence and WAV representation used
    # in the previous 0.2.10 listening experiment.
    assert hashlib.sha256(args.source.read_bytes()).hexdigest() == "ccc1fef039e7c77a0e3d3a8719cf5ec0a775dce5849113b7646a910d11a7b869"
    with wave.open(str(args.source), "rb") as src:
        assert (src.getnchannels(), src.getsampwidth(), src.getframerate()) == (2, 2, 48000)
        src.setpos(10 * 48000)
        pcm = src.readframes(10 * 48000)
    with wave.open(str(args.output), "wb") as dst:
        dst.setnchannels(2)
        dst.setsampwidth(2)
        dst.setframerate(48000)
        dst.writeframes(pcm)
    assert hashlib.sha256(args.output.read_bytes()).hexdigest() == "05234a51af10b01d272bfe5650ebed4ef89d286fc6c15330045c2b9f336b1c8f"
else:
    # Input is the Opus file encoded from the published Golos WAV.
    listing = json.loads(subprocess.check_output([
        "ffprobe", "-v", "error", "-select_streams", "a:0", "-show_packets", "-show_data",
        "-show_entries", "packet=size,data", "-of", "json", args.source,
    ]))
    raw = bytearray()
    for packet in listing["packets"]:
        payload = b"".join(bytes.fromhex(line[10:49]) for line in packet["data"].splitlines() if line)
        assert len(payload) == int(packet["size"])
        raw.extend(len(payload).to_bytes(4, "big"))
        raw.extend(payload)
    assert hashlib.sha256(raw).hexdigest() == "ce8d374d57cb2c8cfb6f169272abd3454f1457bb3bcfbdbe187c1e16d7bf0c67"
    args.output.write_bytes(raw)
