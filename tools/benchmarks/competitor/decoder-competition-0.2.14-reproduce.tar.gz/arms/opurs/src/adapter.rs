use opurs::{Channels, SampleRate};
pub struct Decoder {
    inner: opurs::OpusDecoder,
    channels: usize,
}
impl Decoder {
    pub fn new(rate: usize, channels: usize) -> Result<Self, String> {
        let sample_rate = SampleRate::try_from(rate as i32).map_err(|e| format!("{e:?}"))?;
        let layout = Channels::try_from(channels as i32).map_err(|e| format!("{e:?}"))?;
        let inner = opurs::OpusDecoder::new(sample_rate, layout).map_err(|e| format!("{e:?}"))?;
        Ok(Self { inner, channels })
    }
    pub fn decode(&mut self, packet: &[u8], expected: usize, output: &mut [i16]) -> Result<usize, String> {
        self.inner.decode(packet, &mut output[..expected * self.channels], expected as i32, false)
            .map(|n| n * self.channels)
            .map_err(|e| format!("{e:?}"))
    }
    pub fn final_range(&self) -> Option<u32> {
        Some(self.inner.final_range())
    }
}
