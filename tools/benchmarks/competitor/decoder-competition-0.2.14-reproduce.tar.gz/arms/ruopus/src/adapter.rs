pub struct Decoder(ruopus::OpusDecoder);
impl Decoder {
    pub fn new(rate: usize, channels: usize) -> Result<Self, String> {
        if ![8000,12000,16000,24000,48000].contains(&rate) || ![1,2].contains(&channels) {
            return Err("unsupported output geometry".into());
        }
        Ok(Self(ruopus::OpusDecoder::with_rate(rate as u32, channels)))
    }
    pub fn decode(&mut self, packet: &[u8], _expected: usize, output: &mut [i16]) -> Result<usize, String> {
        let samples = self.0.decode_packet_i16(packet).map_err(|err| format!("{err:?}"))?;
        if samples.len() > output.len() {return Err("output capacity".into());}
        output[..samples.len()].copy_from_slice(&samples);
        Ok(samples.len())
    }
    pub fn final_range(&self) -> Option<u32> { Some(self.0.final_range()) }
}
