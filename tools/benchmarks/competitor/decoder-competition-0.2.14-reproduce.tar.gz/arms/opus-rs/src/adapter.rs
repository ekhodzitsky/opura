use std::cell::RefCell;

thread_local! {
    // Caller scratch is shared across live decoders on this benchmark's worker
    // thread, just as the signed PCM output buffer is shared by all arms.
    static FLOAT_PCM: RefCell<[f32; 11520]> = const { RefCell::new([0.0; 11520]) };
}

pub struct Decoder {
    inner: opus_rs::OpusDecoder,
    channels: usize,
}

impl Decoder {
    pub fn new(rate: usize, channels: usize) -> Result<Self, String> {
        let inner = opus_rs::OpusDecoder::new(rate as i32, channels).map_err(str::to_owned)?;
        Ok(Self { inner, channels })
    }

    pub fn decode(
        &mut self,
        packet: &[u8],
        expected_samples_per_channel: usize,
        output: &mut [i16],
    ) -> Result<usize, String> {
        let requested = expected_samples_per_channel
            .checked_mul(self.channels)
            .filter(|&n| n <= output.len() && n <= 11520)
            .ok_or("buffer too short")?;
        FLOAT_PCM.with(|scratch| {
            let mut scratch = scratch.borrow_mut();
            let float = &mut scratch[..requested];
            let frames = self
                .inner
                .decode(packet, expected_samples_per_channel, float)
                .map_err(str::to_owned)?;
            if frames != expected_samples_per_channel {
                return Err(format!(
                    "expected {expected_samples_per_channel} frames, got {frames}"
                ));
            }
            for (dest, &sample) in output[..requested].iter_mut().zip(float.iter()) {
                if !sample.is_finite() {
                    return Err("nonfinite PCM sample".to_owned());
                }
                // Float audio's nominal full scale is [-1, 1]; Rust's float
                // to integer cast saturates the rounded signed representation.
                *dest = (sample * 32768.0).round() as i16;
            }
            Ok(requested)
        })
    }

    pub fn final_range(&self) -> Option<u32> {
        Some(self.inner.final_range())
    }
}
