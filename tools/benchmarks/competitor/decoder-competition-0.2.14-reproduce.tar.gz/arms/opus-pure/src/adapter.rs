pub struct Decoder {
    inner: opus_pure::OpusDecoder,
    channels: usize,
}

impl Decoder {
    pub fn new(rate: usize, channels: usize) -> Result<Self, String> {
        let inner = opus_pure::OpusDecoder::new(rate as i32, channels)
            .map_err(|err| err.to_string())?;
        Ok(Self { inner, channels })
    }

    pub fn decode(
        &mut self,
        packet: &[u8],
        expected_samples_per_channel: usize,
        output: &mut [i16],
    ) -> Result<usize, String> {
        self.inner
            .decode_s16(packet, expected_samples_per_channel, output)
            .map(|samples| samples * self.channels)
            .map_err(|err| err.to_string())
    }

    pub fn final_range(&self) -> Option<u32> {
        Some(self.inner.final_range())
    }
}
