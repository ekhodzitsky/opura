use std::cell::RefCell;
thread_local! {
    static PCM: RefCell<Vec<f32>> = const { RefCell::new(Vec::new()) };
}

pub struct Decoder {
    inner: rusty_opus::OpusDecoder,
    channels: usize,
}
impl Decoder {
    pub fn new(rate: usize, channels: usize) -> Result<Self, String> {
        let inner = rusty_opus::OpusDecoder::new(rate as i32, channels)
            .map_err(|e| format!("{e:?}"))?;
        PCM.with_borrow_mut(|pcm| {
            let size = rate * 120 / 1000 * channels;
            if pcm.len() < size {
                pcm.resize(size, 0.0);
            }
        });
        Ok(Self { inner, channels })
    }
    pub fn decode(&mut self, packet: &[u8], expected: usize, output: &mut [i16]) -> Result<usize, String> {
        PCM.with_borrow_mut(|pcm| {
            let requested = expected * self.channels;
            let count = self.inner.decode(packet, expected, &mut pcm[..requested])
                .map_err(|e| format!("{e:?}"))? * self.channels;
            if count > requested || count > output.len() {
                return Err(format!("returned {count} samples, requested {requested}"));
            }
            for (sample, &value) in output[..count].iter_mut().zip(&pcm[..count]) {
                if !value.is_finite() {
                    return Err("non-finite PCM".to_owned());
                }
                *sample = (value * 32768.0).round() as i16;
            }
            Ok(count)
        })
    }
    pub fn final_range(&self) -> Option<u32> {
        Some(self.inner.last_range)
    }
}
