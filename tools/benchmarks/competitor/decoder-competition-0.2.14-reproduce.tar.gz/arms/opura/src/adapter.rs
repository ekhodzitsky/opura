use opura::decoder::CompactOpusDecoder;
use opura::silk::{decoder::PcmChannels,resampler::OutputRate};
pub struct Decoder(CompactOpusDecoder);
impl Decoder{
    pub fn new(rate:usize,ch:usize)->Result<Self,String>{
        let rate=match rate{8000=>OutputRate::Khz8,12000=>OutputRate::Khz12,16000=>OutputRate::Khz16,24000=>OutputRate::Khz24,48000=>OutputRate::Khz48,_=>return Err("rate".into())};
        let channels=match ch{1=>PcmChannels::Mono,2=>PcmChannels::Stereo,_=>return Err("channels".into())};
        CompactOpusDecoder::new(rate,channels).map(Self).map_err(|e|e.to_string())
    }
    pub fn decode(&mut self,p:&[u8],_:usize,out:&mut[i16])->Result<usize,String>{self.0.decode_into(p,out).map_err(|e|e.to_string())}
    pub fn final_range(&self)->Option<u32>{Some(self.0.final_range())}
}
