// External benchmark adapter for the system shared libopus. This file is not
// part of the Opura crate.
use std::ffi::{c_int, c_void};
use std::ptr::NonNull;

#[link(name = "libopus.so.0", kind = "dylib", modifiers = "+verbatim")]
extern "C" {
    fn opus_decoder_create(rate: c_int, channels: c_int, error: *mut c_int) -> *mut c_void;
    fn opus_decoder_destroy(decoder: *mut c_void);
    fn opus_decode(
        decoder: *mut c_void,
        packet: *const u8,
        packet_len: i32,
        pcm: *mut i16,
        frame_size: c_int,
        decode_fec: c_int,
    ) -> c_int;
    fn opus_decoder_ctl(decoder: *mut c_void, request: c_int, ...) -> c_int;
}

const OPUS_GET_FINAL_RANGE_REQUEST: c_int = 4031;

pub struct Decoder {
    inner: NonNull<c_void>,
    channels: usize,
}

impl Decoder {
    pub fn new(rate: usize, channels: usize) -> Result<Self, String> {
        if ![8000, 12000, 16000, 24000, 48000].contains(&rate) || ![1, 2].contains(&channels) {
            return Err("unsupported output geometry".to_owned());
        }
        let mut error = 0;
        // Valid sample rate, channel count and writable int pointer; libopus
        // returns an owned state which is released by Drop.
        let ptr = unsafe { opus_decoder_create(rate as c_int, channels as c_int, &mut error) };
        let inner =
            NonNull::new(ptr).ok_or_else(|| format!("opus_decoder_create returned {error}"))?;
        if error != 0 {
            // The handle, if non-null, was returned by opus_decoder_create.
            unsafe { opus_decoder_destroy(inner.as_ptr()) };
            return Err(format!("opus_decoder_create returned {error}"));
        }
        Ok(Self { inner, channels })
    }

    pub fn decode(
        &mut self,
        packet: &[u8],
        expected_samples_per_channel: usize,
        output: &mut [i16],
    ) -> Result<usize, String> {
        let requested = expected_samples_per_channel
            .checked_mul(self.channels)
            .filter(|&n| n <= output.len() && n <= 11520)
            .ok_or("buffer too short")?;
        let packet_len = i32::try_from(packet.len()).map_err(|e| e.to_string())?;
        // The live state is uniquely borrowed, data and output slices are
        // valid, and output has room for the requested interleaved samples.
        let frames = unsafe {
            opus_decode(
                self.inner.as_ptr(),
                packet.as_ptr(),
                packet_len,
                output.as_mut_ptr(),
                expected_samples_per_channel as c_int,
                0,
            )
        };
        if frames < 0 {
            return Err(format!("opus_decode returned {frames}"));
        }
        if frames as usize != expected_samples_per_channel {
            return Err(format!(
                "expected {expected_samples_per_channel} frames, got {frames}"
            ));
        }
        Ok(requested)
    }

    pub fn final_range(&self) -> Option<u32> {
        let mut range = 0u32;
        // OPUS_GET_FINAL_RANGE is a read-only request with a uint32 out-pointer.
        let result = unsafe {
            opus_decoder_ctl(
                self.inner.as_ptr(),
                OPUS_GET_FINAL_RANGE_REQUEST,
                &mut range as *mut u32,
            )
        };
        (result == 0).then_some(range)
    }
}

impl Drop for Decoder {
    fn drop(&mut self) {
        // The decoder owns this state exclusively.
        unsafe { opus_decoder_destroy(self.inner.as_ptr()) };
    }
}
