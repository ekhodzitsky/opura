pub struct Decoder {
    inner: ropus::OpusDecoder,
    channels: usize,
}
impl Decoder {
    pub fn new(rate: usize, channels: usize) -> Result<Self, String> {
        let inner = ropus::OpusDecoder::new(rate as i32, channels as i32).map_err(|err| err.to_string())?;
        Ok(Self{inner,channels})
    }
    pub fn decode(&mut self, packet: &[u8], expected: usize, output: &mut [i16]) -> Result<usize, String> {
        self.inner.decode(Some(packet),output,expected as i32,false).map(|n| n as usize * self.channels).map_err(|err| err.to_string())
    }
    pub fn final_range(&self) -> Option<u32> { Some(self.inner.get_final_range()) }
}
