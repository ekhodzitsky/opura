from pathlib import Path
import argparse,ctypes as C,struct,hashlib,json,subprocess,collections
p=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description='Prepare the 132 cases from exact official vectors and real packet inputs.')
for flag in ['vectors','golos','mandarin','ami','music']:
 parser.add_argument('--'+flag,type=Path,required=True)
args=parser.parse_args()
vectors=args.vectors.resolve()
if (p/'cases.json').exists():parser.error('Use a new reproduction directory; cases.json is already present.')
out=p/'inputs';out.mkdir(exist_ok=True)
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
manifest=json.loads((p/'conformance_manifest.json').read_text())
for name,expected in manifest['sha1'].items(): assert hashlib.sha1((vectors/name).read_bytes()).hexdigest()==expected,name
lib=C.CDLL('libopus.so.0');lib.opus_get_version_string.restype=C.c_char_p;assert lib.opus_get_version_string().decode()=='libopus 1.6.1'
lib.opus_packet_get_nb_samples.argtypes=[C.c_char_p,C.c_int32,C.c_int32];lib.opus_packet_get_nb_samples.restype=C.c_int
lib.opus_decoder_create.argtypes=[C.c_int,C.c_int,C.POINTER(C.c_int)];lib.opus_decoder_create.restype=C.c_void_p
lib.opus_decoder_destroy.argtypes=[C.c_void_p]
lib.opus_decode.argtypes=[C.c_void_p,C.c_char_p,C.c_int32,C.POINTER(C.c_int16),C.c_int,C.c_int];lib.opus_decode.restype=C.c_int
lib.opus_decoder_ctl.argtypes=[C.c_void_p,C.c_int,C.POINTER(C.c_uint32)];lib.opus_decoder_ctl.restype=C.c_int
# Separately typed variadic setter for OPUS_SET_PHASE_INVERSION_DISABLED.
ctl_int=C.CFUNCTYPE(C.c_int,C.c_void_p,C.c_int,C.c_int)(('opus_decoder_ctl',lib))
def read(data,official=False):
 a=[]
 while data:
  n=int.from_bytes(data[:4],'big');offset=8 if official else 4;range_=int.from_bytes(data[4:8],'big') if official else None
  packet=data[offset:offset+n];assert n==len(packet)>0;a.append((packet,range_));data=data[offset+n:]
 return a
def from_ogg(path):
 d=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','a:0','-show_packets','-show_data','-show_entries','packet=size,data','-of','json',path]))
 a=[]
 for row in d['packets']:
  data=b''.join(bytes.fromhex(l[10:49]) for l in row['data'].splitlines() if l);assert len(data)==int(row['size']);a.append((data,None))
 return a
def qualify_real(packets,name,ch,altphase=False):
 err=C.c_int(); state=lib.opus_decoder_create(48000,ch,C.byref(err));assert state and err.value==0
 buf=(C.c_int16*11520)();r=[];pcm=bytearray()
 try:
  if altphase:assert ctl_int(state,4046,0 if ch==1 else 1)==0
  for packet,_ in packets:
   n=lib.opus_decode(state,packet,len(packet),buf,5760,0);assert n>0
   v=C.c_uint32(); assert lib.opus_decoder_ctl(state,4031,C.byref(v))==0
   r.append((packet,v.value))
   if ch==2:
    pcm.extend(C.string_at(buf,4*n))
   else:
    # opus_compare's 48 kHz reference input is always stereo. Preserve
    # native mono decoding by duplicating each direct mono sample.
    for i in range(n):pcm.extend(struct.pack('<hh',buf[i],buf[i]))
 finally:lib.opus_decoder_destroy(state)
 suffix=f'-altphase-{ch}' if altphase else '-mono' if ch==1 else ''
 (out/(name+suffix+'.dec')).write_bytes(pcm)
 return r
cases=[]
def add(name,packets,rate,ch,refs,source):
 records=b''.join(struct.pack('>III',len(d),lib.opus_packet_get_nb_samples(d,len(d),rate),rr or 0)+d for d,rr in packets)
 f=out/(name+f'-{rate}.records')
 if f.exists():assert f.read_bytes()==records
 else:f.write_bytes(records)
 counts=collections.Counter('SILK' if d[0]>>3<12 else 'Hybrid' if d[0]>>3<16 else 'CELT' for d,_ in packets)
 cases.append(dict(id=f'{name}-{rate}-{ch}',name=name,rate=rate,channels=ch,records=f.name,records_sha256=sha(f),source_sha256=source,refs=[str(x) for x in refs],packets=len(packets),samples=sum(lib.opus_packet_get_nb_samples(d,len(d),rate) for d,_ in packets),nonzero_ranges=sum(bool(rr) for _,rr in packets),mode_histogram=counts))
for i in range(1,13):
 name=f'testvector{i:02}';src=vectors/(name+'.bit');packets=read(src.read_bytes(),True)
 for rate in [8000,12000,16000,24000,48000]:
  for ch in [1,2]:add(name,packets,rate,ch,[vectors/(name+'.dec'),vectors/(name+'m.dec')],sha(src))
sources={'golos00':args.golos.resolve(),'mandarin':args.mandarin.resolve(),'ami':args.ami.resolve(),'music64':args.music.resolve()}
for name,src in sources.items():
 packets=from_ogg(src) if name=='music64' else read(src.read_bytes())
 stereo=qualify_real(packets,name,2)
 mono=qualify_real(packets,name,1)
 assert mono==stereo,name
 assert qualify_real(packets,name,1,True)==stereo,name
 assert qualify_real(packets,name,2,True)==stereo,name
 packets=stereo
 for rate,ch in [(16000,1),(48000,1),(48000,2)]:
  add(name,packets,rate,ch,[out/(name+('-mono' if ch==1 else '')+'.dec'),out/(name+f'-altphase-{ch}.dec')],sha(src))
 print(name, cases[-1]['mode_histogram'],len(packets))
 # memory prefix shares exactly the same record representation
 full=out/(name+'-48000.records'); data=full.read_bytes();pos=0
 for _ in range(24):pos+=12+int.from_bytes(data[pos:pos+4],'big')
 (out/(name+'-prefix.records')).write_bytes(data[:pos])
# The SILK memory test uses the 16 kHz record geometry for its own prefix.
golos=(out/'golos00-16000.records').read_bytes()
pos=0
for _ in range(24):
 pos+=12+int.from_bytes(golos[pos:pos+4],'big')
(out/'golos00-16000-prefix.records').write_bytes(golos[:pos])
expected=json.loads((p/'cases.expected.json').read_text())
assert len(cases)==len(expected)==132
for actual,baseline in zip(cases,expected):
 # An Ogg container's serial can change while its decoded packet contents stay
 # identical. The music case must reproduce records and native reference PCM.
 match={**actual,'refs':[Path(x).name for x in actual['refs']],
        'reference_sha256':[sha(Path(x)) for x in actual['refs']]}
 if actual['name']=='music64':
  match['source_sha256']=baseline['source_sha256']
 assert match==baseline,(actual['id'],'case fingerprint or reference mismatch')
for file,digest in json.loads((p/'prefix.sha256.json').read_text()).items():
 assert sha(out/file)==digest,file
(p/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
