// Standalone comparison worker. Adapters return interleaved signed PCM.
mod adapter;
use adapter::Decoder;
use std::{env,fs,io::{BufWriter,Write},fs::File,time::Instant,hint::black_box};
struct Packet<'a>{data:&'a[u8],samples:usize,range:u32}
fn packets(mut bytes:&[u8])->Vec<Packet<'_>>{
    let mut packets=Vec::new();
    while !bytes.is_empty(){
        let n=u32::from_be_bytes(bytes[..4].try_into().unwrap()) as usize;
        let samples=u32::from_be_bytes(bytes[4..8].try_into().unwrap()) as usize;
        let range=u32::from_be_bytes(bytes[8..12].try_into().unwrap());
        packets.push(Packet{data:&bytes[12..12+n],samples,range});
        bytes=&bytes[12+n..];
    }
    assert!(!packets.is_empty());packets
}
fn cpu()->u64 {fs::read_to_string("/proc/thread-self/schedstat").unwrap().split_whitespace().next().unwrap().parse().unwrap()}
fn memory()->[u64;2]{
    let text=fs::read_to_string("/proc/self/smaps_rollup").unwrap();
    ["Rss:","Private_Dirty:"].map(|field|text.lines().find(|l|l.starts_with(field)).unwrap().split_whitespace().nth(1).unwrap().parse().unwrap())
}
fn decode(d:&mut Decoder,p:&Packet<'_>,ch:usize,out:&mut[i16])->Result<usize,String>{
    let n=d.decode(black_box(p.data),p.samples,out)?;
    if n!=ch*p.samples{return Err(format!("sample count {n} expected {}",ch*p.samples));}
    black_box(&out[..n]);Ok(n)
}
fn run(rate:usize,ch:usize,ps:&[Packet],out:&mut[i16],mut times:Option<&mut Vec<u64>>)->Result<(),String>{
    let mut d=Decoder::new(rate,ch)?;
    for p in ps {
        if let Some(samples)=times.as_deref_mut(){let begin=Instant::now();decode(&mut d,p,ch,out)?;samples.push(begin.elapsed().as_nanos() as u64);}
        else{decode(&mut d,p,ch,out)?;}
    }
    Ok(())
}
fn main()->Result<(),String>{
    let a:Vec<_>=env::args().collect();let mode=&a[1];let rate=a[2].parse::<usize>().unwrap();let ch=a[3].parse::<usize>().unwrap();
    let input=fs::read(&a[4]).map_err(|e|e.to_string())?;let ps=packets(&input);
    let mut out=vec![0i16;rate*120/1000*ch];
    match mode.as_str(){
        "qualify"=>{
            let mut d=Decoder::new(rate,ch)?;
            let mut file=BufWriter::new(File::create(&a[5]).map_err(|e|e.to_string())?);
            let mut available=0;let mut checks=0;let mut wrong=0;let mut total=0;
            for p in &ps {
                let n=decode(&mut d,p,ch,&mut out)?;total+=n;
                if let Some(r)=d.final_range(){available+=1;if p.range!=0{checks+=1;wrong+=usize::from(r!=p.range);}}
                for s in &out[..n]{file.write_all(&s.to_le_bytes()).map_err(|e|e.to_string())?;}
            }
            file.flush().map_err(|e|e.to_string())?;
            println!("{} {} {} {} {}",ps.len(),total,available,checks,wrong);
        }
        "cpu"|"latency"=>{
            let repeats=a[5].parse::<usize>().unwrap();assert!(repeats>0);
            run(rate,ch,&ps,&mut out,None)?;
            if mode=="cpu"{
                let begin=cpu();
                for _ in 0..repeats{run(rate,ch,&ps,&mut out,None)?;}
                println!("{}",cpu()-begin);
            }else{
                let mut times=Vec::with_capacity(repeats*ps.len());
                for _ in 0..repeats{run(rate,ch,&ps,&mut out,Some(&mut times))?;}
                times.sort_unstable();println!("{} {}",times.len(),times[(99*times.len()).div_ceil(100)-1]);
            }
        }
        "memory"=>{
            let streams=a[5].parse::<usize>().unwrap();let before=memory();
            let mut states:Vec<_>=(0..streams).map(|_|Decoder::new(rate,ch)).collect::<Result<_,_>>()?;
            let mut expected=vec![0i16;out.len()];let mut total=0usize;
            for p in &ps{
                let mut range=None;
                for (i,d) in states.iter_mut().enumerate(){
                    let n=decode(d,p,ch,&mut out)?;total+=n;
                    if i==0 {expected[..n].copy_from_slice(&out[..n]);range=d.final_range();}
                    else if expected[..n]!=out[..n] || range!=d.final_range(){return Err("independent stream differs".into());}
                }
            }
            black_box(&states);let after=memory();
            println!("{} {} {} {} {}",before[0],before[1],after[0],after[1],total);
        }
        _=>return Err("mode".into())
    }
    Ok(())
}
