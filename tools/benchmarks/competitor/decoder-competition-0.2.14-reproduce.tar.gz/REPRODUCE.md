# Reproduce the Opura 0.2.14 decoder comparison

The archive contains the independent benchmark source, nine adapters and
their exact manifests and lockfiles. It includes no codec implementations,
media, reference executables, compiled libraries or packet captures.

Use little-endian x86-64 Linux with Rust 1.100.0, Python 3.11+, Git, a C
compiler, FFmpeg/ffprobe and installed libopus 1.6.1. The reference system
library was the Ubuntu amd64 libopus0 1.6.1-1 package
(`libopus.so.0.11.1`, SHA-256
`5f01eaf11e7326d83f9c341a1d943851a0b00e3444668697dd663c14b138476e`).
The binary was unmodified, with hardware dispatch enabled by the distribution.
Exact PCM comparison on the real inputs may require the same library and
hardware dispatch. The Rust builds use the default release profile and
default crate features with `RUSTFLAGS="-C target-cpu=native"`. The timed
output is interleaved signed 16-bit PCM for all arms.

## Reference sources and build

Obtain the official RFC 8251 packet and PCM files by extracting the
[official testvector archive](https://opus-codec.org/docs/opus_testvectors-rfc8251.tar.gz)
into a directory. Its SHA-256 is recorded in `conformance_manifest.json`.
That file also contains the individual official SHA-1 fingerprints.

From the extracted benchmark directory, use the following exact references.
The `opurs` manifest refers to the clean sibling source at
`arms/opurs/upstream` and pins its development revision rather than a
registry package, because a published version was unavailable. The
benchmark does not vendor that source.

```sh
rustup toolchain install 1.100.0 --profile minimal
git clone https://github.com/xiph/opus.git opus-reference
git -C opus-reference checkout --detach 22244de5a79bd1d6d623c32e72bf1954b56235be
git clone https://github.com/dignifiedquire/opurs.git arms/opurs/upstream
git -C arms/opurs/upstream checkout --detach f0f8941dcc1836a4564cb12f0d3fbe4c0b0c5a6a
python3 build.py --opus-source opus-reference
```

Add `--offline` to the last command if the locked crate archives are
already present in Cargo's cache. `build.py` validates the clean pinned
opurs source, the reference commit and the metric source digest before
compiling. It copies the common worker into each external crate, builds
with locked dependencies, and prints binary and resolved library hashes.

The adapters are external to Opura's dependency-free production crate.
The system libopus adapter uses `opus_decode` via FFI. Rust adapters that
expose only normalized float PCM convert and saturate to i16 within the
timed region. A decoder whose public API lacks an entropy-range accessor
can qualify based on PCM and count only; its range status remains
unavailable.

## Real recording inputs

The four real inputs must have the original packet content. The first three
are files of contiguous Opus packets prefixed with their four-byte
big-endian payload lengths. The music input is an Ogg Opus file.

- **Golos SILK.** Reuse the public Golos first file (`golos_00`) from the
  [Opura 0.2.8 active speech experiment](https://github.com/ekhodzitsky/opura/blob/v0.2.8/docs/benchmarks/active-speech-capacity-0.2.8.md).
  The source snapshot is
  [GigaSTT a2c09d4](https://github.com/ekhodzitsky/gigastt/tree/a2c09d4ef842158b5a33d0dc5ab01f40c35be059/crates/gigastt/tests/fixtures).
  Encode its `golos_00.wav` with FFmpeg 7.0.2 in VoIP mode, 24 kbit/s CBR
  and 20 ms frames. The previous experiment's extraction script or the
  following commands produce the byte-exact packet file.
- **Mandarin and AMI Hybrid.** Reuse the two 1,600-packet files reconstructed
  with the pinned sipbot and source recordings in the
  [Opura 0.2.13 SIP comparison](https://github.com/ekhodzitsky/opura/blob/v0.2.13/docs/benchmarks/sip-decoder-0.2.13.md).
  That report's reproduction bundle includes the exact Mandarin recording
  source, AMI ES2002a excerpt, SIP negotiation and packet collection recipe.
- **Stereo CELT music.** Download Xiph's
  [music_orig.wav](https://media.xiph.org/opus/samples/examples/music_orig.wav).
  Extract seconds 10–20 as original stereo PCM16 at 48 kHz and encode with
  the published Opura 0.2.10 CLI using its 64 kb/s audio application,
  automatic mode, 20 ms frames and complexity 10. The Ogg stream serial may
  differ. The canonical packet records must match.

```sh
ffmpeg -v error -i /path/to/golos_00.wav -c:a libopus -application voip -b:a 24k -vbr off -frame_duration 20 golos_00.opus
python3 prepare_clips.py golos golos_00.opus golos_00.packets
python3 prepare_clips.py music /path/to/music_orig.wav music_excerpt.wav
cargo +1.100.0 install opura --version 0.2.10 --locked --root ./music-cli
./music-cli/bin/opura encode music_excerpt.wav music64.opus --mode auto --application audio --frame-ms 20 --complexity 10 --bitrate 64000
```

The preparation helper verifies the exact music source and extracted WAV
hash and the exact Golos packet hash. Input preparation creates all 132
qualification case records, verifies each official file, and constructs
native PCM and final range references for each real input using system
libopus. The reference for mono output is direct 48 kHz mono decode with
each sample duplicated into stereo for the metric. The reference for stereo
output is direct 48 kHz stereo decode. In each geometry a second reference
uses the opposite-to-default CELT phase-inversion setting (native decoder
control 4046, value 0 for mono and 1 for stereo). Both modes retain the same
packet final ranges. It verifies record SHA-256, channel geometry, PCM reference
fingerprints and warm-state prefix files against the recorded case
manifest. Only the Ogg-container hash is permitted to differ, since varying
its serial alone does not alter the actual audio packets.

```sh
python3 prepare.py --vectors /path/to/extracted-vectors --golos golos_00.packets \
  --mandarin /path/to/mandarin/packets.bin --ami /path/to/ami/packets.bin \
  --music music64.opus
```

## Qualification and measurements

`prepare.py` emits the local cases with resolved reference paths. Each
standalone process uses the same worker, input geometry, output sample
type and test metric. The details of expected range availability and
qualification are in the worker, adapters and `qualify.py` source.
Qualification uses PCM16 throughout and both official comparison PCM
references. The real-corpus reference is system libopus 1.6.1 decoded directly at
48 kHz with the requested output channel count. The mono reference is
duplicated into stereo only to satisfy opus_compare’s reference format; this
avoids a numerical comparison against a different decoder downmix. The
initial qualification using stereo reference for mono failed both native
music cases. The corrected real-corpus gate accepts either native
phase-inversion setting, because legitimate CELT phase handling differs
across implementations. This mirrors the official pair of references. Both
corrections were finalized before the timing schedule ran. Official reference
files and all timing orders remain identical.

Use a free CPU. The frozen schedule in `protocol.json` used CPU 4, so the
exact scripts assume this logical CPU is available. The following command
qualifies each arm sequentially on CPU 4, then runs the frozen measurement
order. It writes fresh raw JSONL files; use a new extracted directory for
another measurement campaign. CPU totals cover a complete warmed replay,
latency measures individual packet walls separately, and the memory mode
samples resident memory and private dirty memory while all decoder states
remain live.

```sh
python3 - <<'PY'
import json, subprocess
from pathlib import Path
for arm, binary in json.loads(Path("arms.json").read_text()).items():
    subprocess.run(["python3", "qualify.py", arm, binary, "4"], check=True)
PY
python3 measure.py cpu
python3 measure.py latency
python3 measure.py memory
python3 summarize.py
```

The measurement driver includes only the qualified configurations.
Qualification failures and unavailable range APIs remain visible in the
summary. All planned rows and raw process observations are checked against
the schedule before generating `results.json`. Use the separately
published results file for the original measured values and binary hashes.
