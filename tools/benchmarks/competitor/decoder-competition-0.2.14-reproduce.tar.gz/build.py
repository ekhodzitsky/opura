"""Build the frozen comparison adapters and official metric executable."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
OPURS_REV = "f0f8941dcc1836a4564cb12f0d3fbe4c0b0c5a6a"
OPUS_REV = "22244de5a79bd1d6d623c32e72bf1954b56235be"
COMPARE_SHA256 = "387e5486b93899b012065f1c71fe27d96eade36a7c0bd419f03945d124a110c7"

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--opus-source", type=Path, required=True)
parser.add_argument("--offline", action="store_true")
args = parser.parse_args()
arms = json.loads((ROOT / "arms.json").read_text())
plan = json.loads((ROOT / "protocol.json").read_text())

def git(path, *args):
    return subprocess.check_output(["git", "-C", path, *args], text=True).strip()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

source = args.opus_source.resolve()
assert git(source, "rev-parse", "HEAD") == OPUS_REV
compare = source / "src/opus_compare.c"
assert sha(compare) == COMPARE_SHA256
opurs = ROOT / "arms/opurs/upstream"
assert git(opurs, "rev-parse", "HEAD") == OPURS_REV
assert git(opurs, "status", "--porcelain") == ""
subprocess.run(["cc", "-O2", "-std=c99", compare, "-lm", "-o", ROOT / "opus_compare"], check=True)
for arm, executable in arms.items():
    project = ROOT / "arms" / arm
    shutil.copyfile(ROOT / "worker.rs", project / "src/main.rs")
    cmd = ["cargo", "+" + plan["toolchain"], "build", "--release", "--locked"]
    if args.offline:
        cmd.append("--offline")
    env = {
        **os.environ,
        "RUSTFLAGS": plan["rustflags"],
        "CARGO_TARGET_DIR": str(project / "target"),
    }
    subprocess.run(cmd, cwd=project, env=env, check=True)
    assert (ROOT / executable).is_file()
    print(arm, sha(ROOT / executable), flush=True)

native_binary = ROOT / arms["libopus"]
linked = subprocess.check_output(["ldd", native_binary], text=True)
soname = next(line.split("=>")[1].split()[0] for line in linked.splitlines()
             if "libopus.so.0" in line and "=>" in line)
print("resolved libopus SHA256", sha(Path(soname)))
