from pathlib import Path
import sys,subprocess,json,hashlib,tempfile,re,math,os
r=Path(__file__).resolve().parent;arm=sys.argv[1];binary=Path(sys.argv[2]).resolve();cpu=int(sys.argv[3]);os.sched_setaffinity(0,{cpu})
cases=json.loads((r/'cases.json').read_text());output=r/f'qualify-{arm}.jsonl'
if '--real' in sys.argv:
 cases=[c for c in cases if not c['name'].startswith('testvector')];output=r/f'qualify-{arm}-real-final.jsonl'
def metric(ref,pcm,case):
 a=subprocess.run([r/'opus_compare',*(['-s'] if case['channels']==2 else []),'-r',str(case['rate']),ref,pcm],capture_output=True,text=True,timeout=45);txt=a.stdout+a.stderr;m=re.search(r'Opus quality metric: ([^\s]+) %',txt);v=float(m[1]) if m else None
 return dict(passed=a.returncode==0 and 'Test vector PASSES' in txt and v is not None and math.isfinite(v) and 0<=v<=100,quality=v if v is not None and math.isfinite(v) else None)
with tempfile.TemporaryDirectory(dir=r) as work,output.open('x') as f:
 pcm=Path(work)/'pcm.raw'
 for case in cases:
  pcm.unlink(missing_ok=True); rec={'id':case['id']}
  try:
   q=subprocess.run([binary,'qualify',str(case['rate']),str(case['channels']),r/'inputs'/case['records'],pcm],capture_output=True,text=True,timeout=60)
   if q.returncode!=0:
    rec.update(passed=False,exit=q.returncode,error=' '.join(s for s in q.stderr.splitlines() if '/' not in s and s.strip())[:260])
   else:
    packets,samples,available,checks,wrong=map(int,q.stdout.split())
    metrics=[metric(ref,pcm,case) for ref in case['refs']]
    complete=packets==case['packets'] and samples==case['samples']*case['channels'] and pcm.stat().st_size==2*samples
    range_status='unavailable' if available==0 else 'passed' if available==packets and checks==case['nonzero_ranges'] and wrong==0 else 'failed'
    rec.update(passed=complete and any(m['passed'] for m in metrics) and range_status!='failed',complete=complete,range_status=range_status,packets=packets,samples=samples,available=available,range_checks=checks,range_wrong=wrong,metrics=metrics,pcm_sha256=hashlib.sha256(pcm.read_bytes()).hexdigest())
  except (subprocess.TimeoutExpired,ValueError) as e:rec.update(passed=False,error=type(e).__name__)
  f.write(json.dumps(rec)+'\n');f.flush()
print(arm,len(cases),flush=True)
