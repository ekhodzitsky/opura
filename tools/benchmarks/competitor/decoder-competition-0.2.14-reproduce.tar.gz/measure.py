from pathlib import Path
import sys,subprocess,json,os
r=Path(__file__).resolve().parent
plan=json.loads((r/'protocol.json').read_text())
arms=json.loads((r/'arms.json').read_text());cases={c['id']:c for c in json.loads((r/'cases.json').read_text())}
qa={}
for a,b in arms.items():
 assert (r/b).is_file()
 rows=[json.loads(x) for x in (r/f'qualify-{a}.jsonl').read_text().splitlines()]
 assert len(rows)==len(cases) and {x['id'] for x in rows}==cases.keys(),a
 qa[a]={x['id']:x for x in rows}
os.sched_setaffinity(0,{plan['cpu']})
def invoke(a,row,mode):
 c=cases[row['case']]
 if mode=='memory':
  path='golos00-16000-prefix.records' if c['name']=='golos00' else c['name']+'-prefix.records'
  argument=row['streams']
 else:path=c['records'];argument=row['repeats']
 rec={k:v for k,v in row.items() if k!='arms'};rec['arm']=a
 try:
  proc=subprocess.run([r/arms[a],mode,str(c['rate']),str(c['channels']),r/'inputs'/path,str(argument)],capture_output=True,text=True,timeout=75)
  if proc.returncode:rec.update(error=' '.join(x for x in proc.stderr.splitlines() if '/' not in x and x.strip())[:260],exit=proc.returncode)
  else:
   vals=list(map(int,proc.stdout.split()))
   if mode=='cpu':
    assert len(vals)==1 and vals[0]>0;rec['cpu_ns']=vals[0]
   elif mode=='latency':
    assert len(vals)==2 and vals[0]==c['packets']*argument and vals[1]>0;rec['packets'],rec['p99_ns']=vals
   else:
    assert len(vals)==5;rec['before']=vals[:2];rec['warm']=vals[2:4];rec['samples']=vals[4]
  return rec
 except (subprocess.TimeoutExpired,ValueError,AssertionError) as e:rec['error']=type(e).__name__;return rec
phase=sys.argv[1]
rows=plan['memory'] if phase=='memory' else [x for x in plan['timing'] if x['phase']==phase]
with (r/(phase+'.jsonl')).open('x') as out:
 for i,row in enumerate(rows):
  for a in row['arms']:
   if not qa[a][row['case']]['passed']:continue
   rec=invoke(a,row,phase);out.write(json.dumps(rec)+'\n');out.flush()
  if i%12==0:print(phase,i+1,len(rows),flush=True)
