from pathlib import Path
import json,statistics as s,math,random,hashlib,collections,sys
r=Path(__file__).resolve().parent
cases={c['id']:c for c in json.loads((r/'cases.json').read_text())}
arms=json.loads((r/'arms.json').read_text())
read=lambda name:[json.loads(x) for x in (r/name).read_text().splitlines()]
qa={a:read(f'qualify-{a}.jsonl') for a in arms}
summary={}
for a,rows in qa.items():
 assert len(rows)==len(cases) and {x['id'] for x in rows}==cases.keys()
 groups={kind:[x for x in rows if cases[x['id']]['name'].startswith('testvector')==(kind=='official')] for kind in ['official','real']}
 summary[a]={k:dict(passed=sum(x['passed'] for x in v),total=len(v),all_ranges_where_available=sum(x.get('range_checks',0) for x in v),range_failed=sum(x.get('range_wrong',0) for x in v),range_unavailable=sum(x.get('range_status')=='unavailable' for x in v),failures=[x['id'] for x in v if not x['passed']]) for k,v in groups.items()}
plan=json.loads((r/'protocol.json').read_text())
cpu=read('cpu.jsonl');lat=read('latency.jsonl');mem=read('memory.jsonl')
for phase,rows in [('cpu',cpu),('latency',lat),('memory',mem)]:
 exp=plan['memory'] if phase=='memory' else [x for x in plan['timing'] if x['phase']==phase]
 keys=lambda row:(row['round'],row['case'],row.get('streams',row.get('repeats')),row['arm'])
 expected=[keys({**row,'arm':a}) for row in exp for a in row['arms'] if next(x['passed'] for x in qa[a] if x['id']==row['case'])]
 assert [keys(x) for x in rows]==expected,phase
def values(rows,a,c,key):
 vals={x['round']:x[key]/x['repeats'] if key=='cpu_ns' else x[key] for x in rows if x['arm']==a and x['case']==c and key in x}
 return vals
def pair(base,other):
 common=sorted(base.keys()&other.keys())
 if len(common)<2:return None
 ratios=[math.log(other[i]/base[i]) for i in common]
 rng=random.Random(129)
 boot=sorted(math.exp(s.mean(rng.choices(ratios,k=len(ratios)))) for _ in range(10000))
 return dict(ratio=math.exp(s.mean(ratios)),ci=[boot[249],boot[9749]],rounds=len(common))
timing={}
for cid,c in cases.items():
 if not any(x['case']==cid for x in cpu):continue
 timing[cid]={}
 for a in arms:
  cs=values(cpu,a,cid,'cpu_ns');ls=values(lat,a,cid,'p99_ns')
  if not cs or not ls:continue
  duration=c['samples']/c['rate']
  timing[cid][a]={'median_cpu_ms_per_audio_second':s.median(cs.values())/1e6/duration,'median_p99_us':s.median(ls.values())/1000,'cpu_vs_opura':pair(values(cpu,'opura',cid,'cpu_ns'),cs),'p99_vs_opura':pair(values(lat,'opura',cid,'p99_ns'),ls)}
aggregate={}
for geom in [(16000,1),(48000,2)]:
 name=f'{geom[0]}-{geom[1]}';aggregate[name]={}
 for a in arms:
  eligible=[c for c in timing if cases[c]['name'].startswith('testvector') and (cases[c]['rate'],cases[c]['channels'])==geom and a in timing[c] and 'opura' in timing[c]]
  old={};new={}
  for round_ in range(1,6):
   try:
    old[round_]=sum(values(cpu,'opura',c,'cpu_ns')[round_] for c in eligible);new[round_]=sum(values(cpu,a,c,'cpu_ns')[round_] for c in eligible)
   except KeyError:old.pop(round_,None);new.pop(round_,None)
  if eligible and old and new:aggregate[name][a]={'vectors':len(eligible),'ratio_vs_opura':pair(old,new),'duration_s':sum(cases[c]['samples']/cases[c]['rate'] for c in eligible),'median_cpu_ms_per_audio_second':s.median(new.values())/1e6/sum(cases[c]['samples']/cases[c]['rate'] for c in eligible)}
memory={}
for cid in sorted(set(x['case'] for x in mem)):
 memory[cid]={}
 for a in arms:
  group=[x for x in mem if x['case']==cid and x['arm']==a and 'warm' in x]
  groups={n:[x for x in group if x['streams']==n] for n in [1,128,768]}
  if not all(len(v)==5 for v in groups.values()):continue
  med={n:{'rss_kib':s.median(x['warm'][0] for x in v),'private_dirty_kib':s.median(x['warm'][1] for x in v),'private_dirty_delta_kib':s.median(x['warm'][1]-x['before'][1] for x in v)} for n,v in groups.items()}
  memory[cid][a]={'by_streams':med,'incremental_private_dirty_kib_per_stream':(med[768]['private_dirty_delta_kib']-med[128]['private_dirty_delta_kib'])/640}
public_cases=[{**{k:v for k,v in c.items() if k!='refs'},'reference_sha256':[hashlib.sha256(Path(x).read_bytes()).hexdigest() for x in c['refs']]} for c in cases.values()]
result={'protocol':plan,'protocol_sha256':hashlib.sha256((r/'protocol.json').read_bytes()).hexdigest(),'cases':public_cases,'qualification_summary':summary,'qualification':qa,'per_case':timing,'official_pairwise':aggregate,'memory':memory,'raw':{'cpu':cpu,'latency':lat,'memory':mem},'worker_sha256':hashlib.sha256((r/'worker.rs').read_bytes()).hexdigest(),'binaries_sha256':{a:hashlib.sha256((r/b).read_bytes()).hexdigest() for a,b in arms.items()},'host':'AMD Ryzen AI 9 HX 370, Linux x86-64'}
(r/'results.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
for a,v in summary.items():print(a,v['official']['passed'],v['real']['passed'])
for c in ['golos00-16000-1','mandarin-48000-1','ami-48000-1','music64-48000-2']:
 print(c,[(a,round(v['median_cpu_ms_per_audio_second'],3),round(v['median_p99_us'],1)) for a,v in timing[c].items()])
for c,group in memory.items():
 print('memory',c,[(a,round(v['incremental_private_dirty_kib_per_stream'],1)) for a,v in group.items()])
