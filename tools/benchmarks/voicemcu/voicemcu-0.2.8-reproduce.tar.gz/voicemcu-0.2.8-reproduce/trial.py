from pathlib import Path
import argparse,csv,json,math,os,signal,socket,statistics,subprocess,threading,time,random,sys
D=Path(__file__).resolve().parent
def sample(pid):
 s=Path(f'/proc/{pid}/stat').read_text().split()
 rss={}
 for line in Path(f'/proc/{pid}/smaps_rollup').read_text().splitlines():
  k,_,v=line.partition(':')
  if k in ('Rss','Private_Dirty','Private_Clean'): rss[k]=int(v.split()[0])
 return {'t':time.monotonic(),'cpu':(int(s[13])+int(s[14]))/os.sysconf('SC_CLK_TCK'),**rss}
def quant(a,p):return sorted(a)[max(0,math.ceil(len(a)*p)-1)] if a else None
def run(arm,n,frames,roundno,folder):
 group=8; assert n%group==0
 out=folder/f'{roundno}-{n}-{arm}';out.mkdir()
 sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close()
 addr=f'127.0.0.1:{port}';cert=D/'pilot.crt';key=D/'pilot.key'
 config=out/'config.toml';config.write_text(f'bind="{addr}"\ncert_file="{cert}"\nkey_file="{key}"\nconnect_burst_per_ip={max(n+6,10)}\n')
 with (out/'server.log').open('w') as log:
  server=subprocess.Popen(['taskset','-c','3',str(D/(arm+'-server')),'--config',str(config)],stdout=log,stderr=log,env=dict(os.environ,RUST_LOG='info',NO_COLOR='1',TOKIO_WORKER_THREADS='1'))
  client=None
  try:
   for _ in range(120):
    if server.poll() is not None:raise RuntimeError((out/'server.log').read_text()[-1000:])
    if 'voicemcu server listening' in (out/'server.log').read_text(): break
    time.sleep(.05)
   else:raise RuntimeError('listener not ready')
   idle=sample(server.pid)
   data=out/'packets.csv'
   with (out/'client.log').open('w+') as clog:
    client=subprocess.Popen(['taskset','-c','4-7',str(D/'load-client'),addr,str(n),str(frames),str(group),str(cert),str(data)],stdout=subprocess.PIPE,stderr=clog,text=True,bufsize=1)
    samples=[]
    for line in client.stdout:
     print(line.strip(),file=clog,flush=True)
     cols=line.split()
     if cols[0]=='start':
      start=sample(server.pid); startus=int(cols[1])
      stop=threading.Event()
      def acc():
       while not stop.wait(.2):samples.append(sample(server.pid))
      th=threading.Thread(target=acc);th.start()
     if cols[0]=='end':
      end=sample(server.pid);endus=int(cols[1]);stop.set();th.join()
    if client.wait(timeout=5)!=0:raise RuntimeError((out/'client.log').read_text()[-1500:])
   recv={}; sent={}
   for typ,i,t,seq,label,rms in csv.reader(data.open()):
    i,t,seq,label=map(int,(i,t,seq,label))
    if typ=='send':
     sent.setdefault(i//group,[]).append((t,label))
    else:recv.setdefault(i,[]).append((t,seq,label,float(rms)))
   gaps=[]; delays=[]; attempted=0; positive=0; audible=0; obs=0
   listener_rates=[]
   for i in range(n):
    arr=recv.get(i,[])
    arr0=[x for x in arr if startus<=x[0]<endus]
    if i%group!=0:
     listener_rates.append(len(arr0)*1e6/(endus-startus))
     gaps.extend([(b[0]-a[0])/1000 for a,b in zip(arr0,arr0[1:])])
    if i%group==1:
     obs+=len(arr0);audible+=sum(x[3]>.015 for x in arr0)
     markers=sent[i//group]
     for t,l in markers:
      if t<startus or t>endus-200_000:continue
      attempted+=1
      prev=[label for tt,_,label,_ in arr if (t-70_000)<=tt<t and label!=-1]
      if not prev or prev[-1]!=1-l:continue
      hit=next((tt for tt,_,label,_ in arr if t<=tt<t+200_000 and label==l),None)
      if hit is not None:delays.append((hit-t)/1000)
   dur=(endus-startus)/1e6
   summary={'arm':arm,'n':n,'round':roundno,'group':group,'seconds':dur,'cpu_cores':(end['cpu']-start['cpu'])/dur,'rss_mib':statistics.median([x['Rss'] for x in [start,*samples,end]])/1024,'idle_rss_mib':idle['Rss']/1024,'private_mib':statistics.median([(x['Private_Dirty']+x['Private_Clean'])/1024 for x in [start,*samples,end]]),'talker_markers':attempted,'matched':len(delays),'audible':audible,'observed':obs,'recv_fps_median':statistics.median(listener_rates),'recv_fps_min':min(listener_rates),'gap_p99_ms':quant(gaps,.99),'marker_p50_ms':quant(delays,.5),'marker_p95_ms':quant(delays,.95),'abnormal':sum(k in (out/'server.log').read_text().lower() for k in ['panicked','mix: decode failed'])}
   (out/'result.json').write_text(json.dumps({'summary':summary,'samples':samples,'start':start,'end':end,'idle':idle,'marker_delays_ms':delays,'listener_fps':listener_rates},indent=2))
   print(json.dumps(summary),flush=True)
  finally:
   if client and client.poll() is None:client.terminate();client.wait()
   if server.poll() is None:server.send_signal(signal.SIGINT)
   try:server.wait(timeout=5)
   except subprocess.TimeoutExpired:server.kill();server.wait()
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--sizes',default='8,64,128');p.add_argument('--rounds',type=int,default=3);p.add_argument('--frames',type=int,default=200);p.add_argument('--arms',default='baseline,candidate');a=p.parse_args()
 folder=D/a.out;folder.mkdir();rng=random.Random(20261126)
 for r in range(a.rounds):
  sizes=list(map(int,a.sizes.split(',')));rng.shuffle(sizes)
  for n in sizes:
   order=a.arms.split(',');rng.shuffle(order)
   for arm in order:run(arm,n,a.frames,r,folder)
