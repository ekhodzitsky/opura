from pathlib import Path
import subprocess, time, threading, os, sys, json, random
import trial
D=Path(__file__).resolve().parent
Popen=subprocess.Popen
CAP_MIB=int(os.getenv('PILOT_CAP_MIB','20'))
def capped(which,n,r,folder):
    unit=f'opura-local-codec-validation-{os.getpid()}-{which}-{r}'
    name=f'{unit}.scope'
    tracking={'peak_bytes':0,'events':{},'limit_bytes':CAP_MIB*1024*1024}
    done=threading.Event()
    client=[None]; server=[None]; thread=[None]
    def spawn(args,*a,**kw):
        if args[0]!='taskset':return Popen(args,*a,**kw)
        is_server='server' in args[3]
        if not is_server:
            client[0]=Popen(args,*a,**kw)
            return client[0]
        args=['systemd-run','--user','--scope','--quiet','--unit',unit,'-p',f'MemoryMax={CAP_MIB}M','-p','MemorySwapMax=0','--',*args]
        server[0]=Popen(args,*a,**kw)
        def monitor():
            pid=server[0].pid
            start=time.monotonic()
            while not done.wait(.015):
                try:
                    grp=Path('/proc',str(pid),'cgroup').read_text().split('0::')[1].strip()
                    if grp.endswith('/'+name):
                        base=Path('/sys/fs/cgroup'+grp)
                        tracking['peak_bytes']=max(tracking['peak_bytes'],int((base/'memory.peak').read_text()))
                        assert int((base/'memory.max').read_text())==tracking['limit_bytes']
                        assert int((base/'memory.swap.max').read_text())==0
                        for line in (base/'memory.events').read_text().splitlines():
                            k,v=line.split();tracking['events'][k]=max(tracking['events'].get(k,0),int(v))
                except (FileNotFoundError,ProcessLookupError):pass
                if client[0] and client[0].poll() is None and (server[0].poll() is not None or time.monotonic()-start>25):
                    client[0].terminate()
        thread[0]=threading.Thread(target=monitor);thread[0].start()
        return server[0]
    subprocess.Popen=spawn
    try:
        trial.run(which,n,250,r,folder);tracking['finished']=True
    except Exception as ex:
        tracking['finished']=False;tracking['error_class']=type(ex).__name__
    finally:
        done.set()
        if thread[0]:thread[0].join()
        subprocess.Popen=Popen
        tracking['server_returncode']=server[0].poll() if server[0] else None
        res=subprocess.run(['systemctl','--user','show',name,'-p','Result','--value'],text=True,capture_output=True)
        tracking['scope_result']=res.stdout.strip()
        subprocess.run(['systemctl','--user','reset-failed',name],capture_output=True)
    tracking.update(arm=which,n=n,round=r)
    (folder/f'{r}-{n}-{which}'/'cap.json').write_text(json.dumps(tracking,indent=2))
    print(json.dumps(tracking),flush=True)
if __name__=='__main__':
    folder=D/f'cap{CAP_MIB}';folder.mkdir()
    rng=random.Random(4624)
    for r in range(3):
        arms=['baseline','candidate'];rng.shuffle(arms)
        for arm in arms:capped(arm,64,r,folder)
