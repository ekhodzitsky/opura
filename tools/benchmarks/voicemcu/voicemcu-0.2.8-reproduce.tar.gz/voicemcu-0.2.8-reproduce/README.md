# Repeat the VoiceMCU A/B test

On Linux x86-64, extract the archive in a new directory. The original run used Rust 1.100.0, system libopus 1.6.1 and logical CPUs 3 (server) and 4–7 (client). Install the system native libopus development files and Rust toolchain. Adjust CPU affinity in trial.py for another host. The version of libopus affects this comparison.

```sh
git clone https://github.com/Cod-e-Codes/voicemcu.git voicemcu
git -C voicemcu checkout --detach d7e2748732bdb2b57368c6ef8a47596310ff5162
mkdir candidate
git -C voicemcu archive HEAD | tar -x -C candidate
git -C candidate apply ../candidate.patch
cp stock.Cargo.lock voicemcu/Cargo.lock
cp opura.Cargo.lock candidate/Cargo.lock
mkdir -p voicemcu/server/src/bin
cp local-observer.rs voicemcu/server/src/bin/local-observer.rs
export LIBOPUS_LIB_DIR="$(pkg-config --variable=libdir opus)"
(cd voicemcu && cargo +1.100.0 build --release --locked -p voicemcu-server --bins)
cp voicemcu/target/release/voicemcu-server baseline-server
cp voicemcu/target/release/local-observer load-client
(cd candidate && cargo +1.100.0 build --release --locked -p voicemcu-server --bin voicemcu-server)
cp candidate/target/release/voicemcu-server candidate-server
python3 -u trial.py --out measurements --sizes 8,64,128 --rounds 3 --frames 250
PILOT_CAP_MIB=20 python3 -u capped.py
PILOT_CAP_MIB=16 python3 -u capped.py
```

The application creates its own temporary certificate and key on first start. All participants join an ephemeral loopback port through the upstream QUIC protocol. Never publish generated keys. Capped trials require a working local systemd user manager, cgroup v2 memory controller and permission to run a local per-user transient scope. Only the server enters that scope. The client target, sample cadence under load and classifier are in local-observer.rs. OOM certification uses the systemd scope result and the server exit code. The polling monitor records the maximum observed kernel memory.peak and memory.events counters before teardown. It may miss counters present at the instant of OOM. The collection does not record a memory.current time series. The Python runner default --frames is 200; the published trial used 250. Using a different host, dependency resolver, kernel or libopus build can change the results.

VoiceMCU source context in candidate.patch is available under the included UPSTREAM-LICENSE. Opura uses the project license. The headless client and Python test drivers are provided with the Opura license.
