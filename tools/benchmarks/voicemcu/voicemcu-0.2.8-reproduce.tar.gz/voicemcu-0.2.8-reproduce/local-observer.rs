use quinn::Endpoint;
use rustls::RootCertStore;
use std::{error::Error,fs::File,io::{BufRead,BufReader,Write},sync::Arc,time::{Duration,Instant}};
use voicemcu_common::codec::{OpusEncoder, OpusDecoder};
use voicemcu_common::audio::SILENCE_FRAME;
use voicemcu_common::protocol::*;
type E=Box<dyn Error+Send+Sync>;
const SEG:usize=15;
fn main()->Result<(),E> {tokio::runtime::Builder::new_multi_thread().worker_threads(4).enable_all().build()?.block_on(run())}
fn tables(f:f32)->[(f32,f32);FRAME_SIZE] {std::array::from_fn(|i|{let a=std::f32::consts::TAU*f*i as f32/48000.; (a.sin(),a.cos())})}
fn energy(x:&[f32;FRAME_SIZE],t:&[(f32,f32);FRAME_SIZE])->f32 {
    let (a,b)=x.iter().zip(t).fold((0.,0.),|(a,b),(v,(s,c))|(a+v*s,b+v*c)); a*a+b*b
}
async fn run()->Result<(),E>{
    rustls::crypto::ring::default_provider().install_default().ok();
    let args:Vec<_>=std::env::args().collect();
    let addr=args[1].parse()?;let n:usize=args[2].parse()?;let frames:usize=args[3].parse()?;let group:usize=args[4].parse()?;
    let mut roots=RootCertStore::empty();let cert=rustls_pemfile::certs(&mut BufReader::new(File::open(&args[5])?)).next().ok_or("cert")??;roots.add(cert)?;
    let mut endpoint=Endpoint::client("127.0.0.1:0".parse()?)?;
    endpoint.set_default_client_config(quinn::ClientConfig::with_root_certificates(Arc::new(roots))?);
    let mut peers=Vec::new();
    let origin=Instant::now();
    let tones=[tables(400.),tables(800.)];
    let mut voiced=Vec::new();let mut quiet=Vec::new();
    let mut te=OpusEncoder::new(DEFAULT_BITRATE)?;let mut qe=OpusEncoder::new(DEFAULT_BITRATE)?;
    for i in 0..frames{
        let a=tones[i/SEG%2].map(|(s,_)|s*0.32);
        let mut o=[0u8;MAX_OPUS_PACKET_SIZE]; let len=te.encode(&a,&mut o)?;voiced.push(o[..len].to_vec());
        let len=qe.encode(&SILENCE_FRAME,&mut o)?;quiet.push(o[..len].to_vec());
    }
    for i in 0..n{
        let c=endpoint.connect(addr,"localhost")?.await?; let(mut send,mut recv)=c.open_bi().await?;
        write_signal(&mut send,&SignalMessage::Join{room_code:format!("room{}",i/group),display_name:format!("peer{i}")}).await?;
        let id=match read_signal(&mut recv).await?{SignalMessage::Joined{client_id}=>client_id,x=>return Err(format!("join {x:?}").into())};
        if !matches!(read_signal(&mut recv).await?, SignalMessage::RoomInfo{..}) {return Err("RoomInfo".into())}
        let drain=c.clone();tokio::spawn(async move{while let Ok(mut rx)=drain.accept_uni().await {let _=rx.read_to_end(131072).await;}});
        tokio::spawn(async move{while read_signal(&mut recv).await.is_ok(){};drop(send)});
        peers.push((c,id));
    }
    let rows=Arc::new(std::sync::Mutex::new(Vec::new()));
    for i in 0..n{
        let c=peers[i].0.clone(); let rows=rows.clone(); let active=i%group==0;
        let classify=i%group==1;
        tokio::spawn(async move{
            let mut d=OpusDecoder::new().expect("observer decoder");
            while let Ok(b)=c.read_datagram().await{
                let t=origin.elapsed().as_micros() as u64;let (h,p)=decode_audio_datagram(&b).unwrap();
                let (mut label,mut rms)=(-1,0.);
                if classify{
                    let mut o=SILENCE_FRAME;
                    if d.decode(p,&mut o).unwrap()!=FRAME_SIZE {panic!("duration")}
                    let e0=energy(&o,&tones[0]);let e1=energy(&o,&tones[1]);rms=(o.iter().map(|x|x*x).sum::<f32>()/FRAME_SIZE as f32).sqrt();
                    if rms>0.015 {label=if e0>4.*e1{0}else if e1>4.*e0{1}else{-1};}
                }
                rows.lock().unwrap().push((i,t,h.sequence,label,rms,active));
            }
        });
    }
    println!("joined {n}");std::io::stdout().flush()?;
    let mut sout=File::create(&args[6])?;
    use tokio::io::AsyncWriteExt;
    let mut ticks=tokio::time::interval(Duration::from_millis(20));
    ticks.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Delay);
    for k in 0..frames{
        ticks.tick().await;
        if k==50{println!("start {}",origin.elapsed().as_micros());std::io::stdout().flush()?}
        for (i,(conn,id)) in peers.iter().enumerate(){
            let head=AudioFrameHeader{client_id:*id,sequence:k as u32,timestamp:(k*FRAME_SIZE) as u32};
            conn.send_datagram(encode_audio_datagram(&head,if i%group==0{&voiced[k]}else{&quiet[k]}).into())?;
            if i%group==0 && k%SEG==0{writeln!(sout,"send,{i},{},{k},{},0",origin.elapsed().as_micros(),k/SEG%2)?}
        }
    }
    println!("end {}",origin.elapsed().as_micros());std::io::stdout().flush()?;
    tokio::time::sleep(Duration::from_millis(150)).await;
    for (i,t,s,l,r,_) in rows.lock().unwrap().drain(..){writeln!(sout,"recv,{i},{t},{s},{l},{r}")?;}
    endpoint.close(0u32.into(),b"trial complete"); Ok(())
}
